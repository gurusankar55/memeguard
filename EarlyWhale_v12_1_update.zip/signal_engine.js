// EarlyWhale Signal Engine v12.1
// Finds young pump.fun coins in the 5K-25K USD market-cap zone that look
// organic, rejects rug / dump patterns, learns "smart wallets" and bad devs
// from what it sees, and tracks what happened after every signal.
// Analysis only. Never buys, sells, signs or sends anything.

require("dotenv").config({ quiet: true });
const fs = require("fs");
const path = require("path");
const intel = require("./wallet_intel");

// ---------------- SETTINGS (change here) ----------------
const CFG = {
  ZONE_MIN_USD: 5000,          // signal zone: lowest market cap
  ZONE_MAX_USD: 40000,         // signal zone: highest market cap (v10: 5-min rule -> winners are a bit higher)
  RADAR_MIN_USD: 3000,         // "approaching" list starts here
  MIN_AGE_SEC: 300,            // v10: coin must survive its first 5 minutes (bot pumps die in 5-7 min)
  MAX_AGE_MIN: 90,             // older than this = not "early" any more
  MIN_UNIQUE_BUYERS: 12,       // total different buyer wallets (winners at $10K: 13-84)
  MIN_BUYERS_5M: 8,            // different buyers in last 5 min
  MAX_TOP1_PCT: 10,            // one wallet (not dev) max 10% (winners up to 9.4%)
  MAX_TOP10_PCT: 45,           // top 10 together max 45% (winners up to 40%)
  MAX_DEV_PCT: 8,              // creator may hold max 8%
  DEV_DUMP_SUPPLY_PCT: 10,     // dev sold >=10% of TOTAL supply -> reject forever (small dev exits are normal: 4/5 winners)
  MAX_BUNDLE_PCT: 40,          // launch-second wallets: only EXTREME bundles rejected (winners had 15-54%)
  BUNDLE_SELL_REJECT: 0.25,    // ...but if bundle wallets already sold 25%+ of what they bought -> no entry
  MIN_HOLD_RATIO: 0.5,         // holders / buyers below 50% = flippers & bots -> no entry
  HOLDERS_FALL_PCT: 0.9,       // holders now < 90% of 2 min ago -> no entry
  DIP_MIN: 0.6, DIP_MAX: 0.85, // first-dip entry: pullback of 15-40% from the recent high
  DIP_BOUNCE: 1.07,            // ...and price bounced 7%+ from the dip low
  SPIKE_1M: 1.35,              // price +35% in the last minute = vertical candle, wait
  STEADY_READY_SEC: 90,        // steady entry: ready for 90s, climbing calmly, holders rising
  MOMENTUM_CONFIRM_SEC: 30,    // momentum entry: conditions must hold 30s (no first-minute chasing)
  TIME_STOP_MIN: 20,           // after signal: no move (max < 1.3x) in 20 min -> soft warning
  HOLDERS_EXIT_DROP: 0.75,     // after signal: holders fell to 75% of their peak -> EXIT
  GROUP_EXIT_LEFT: 0.7,        // after signal: bundle / top-10 group kept < 70% of their bag -> EXIT
  FEE_ROUND_TRIP: 0.025,       // pump.fun ~1.25% each way (paper trade)
  MAX_SNIPER_PCT: 15,          // first-5-second buyers hold > 15% -> no entry
  BURST_SHARE: 0.5,            // more than half of holders arrived in the last 60s -> bot swarm
  SAME_SECOND_SAME_SIZE: 5,    // 5+ buys in the same second with the same amount -> bot swarm
  MAX_FRESH_SHARE: 0.6,        // 60%+ of checked buyers are wallets < 2h old -> bot swarm
  PARABOLIC_X: 5,              // x5 within ~3 min with no real pullback = coordinated pump
  DUMP_TEST: 0.8,              // "first dump": price fell to 80% of its high...
  DUMP_RECOVER: 1.1,           // ...and recovered 10% with holders kept (80%)
  EARLY_SELL_RATIO: 0.7,       // first 20 buyers already sold 70% of their coins while price is high -> they are selling to you
  FRESH_BIG_HOLD_SEC: 120,     // "big new wallets" count as good only if they held 2 minutes
  // v11
  MAX_REAL_TOP10_PCT: 45,      // real on-chain top 10 (incl. wallets that got coins by transfer) max 45%
  MAX_REAL_TOP1_PCT: 12,       // one real holder max 12%
  REVIVAL_BUYERS_5M: 25,       // an old/untracked coin with 25+ different buyers in 5 min = revival
  REVIVAL_MIN_USD: 5000,
  OUTCOME_CHECK_H: [1, 6, 24], // after graduation: check DexScreener at 1h, 6h, 24h (true result)
  SMART_ALERT_WALLETS: 2,      // 2+ smart / my wallets buy the same coin within 10 min -> Telegram
  SMART_ALERT_MAX_USD: 40000,
  LADDER_RISE_10M: 2.5,        // price x2.5 in 10 min ...
  LADDER_TOP3_SHARE: 0.55,     // ... and 3 wallets paid 55%+ of the buying = "ladder" pump (step by step, then one-candle dump)
  LADDER_MAX_BUYERS: 35,
  // v11.3 Floor Hunter: buy close to the pump.fun starting price (the curve can't go below it -> small worst-case loss)
  FLOOR_SOL: 27.96,            // every pump.fun coin starts at ~28 SOL market cap (30 vSOL / 1.073B tokens)
  FLOOR_MAX_X: 1.5,            // enter only up to 1.5x the floor (worst case ~ -33%)
  FLOOR_MIN_AGE_SEC: 30,
  FLOOR_MAX_AGE_SEC: 240,
  FLOOR_MIN_BUYERS: 8,
  FLOOR_MIN_BUYERS_1M: 4,      // at least 4 different buyers in the last minute
  FLOOR_MAX_TOP1_PCT: 8,
  FLOOR_MAX_DEV_PCT: 10,
  FLOOR_MAX_EARLY_PCT: 15,     // bundle + snipers together max 15%
  FLOOR_MIN_HOLD_RATIO: 0.6,
  FLOOR_TIME_STOP_MIN: 15,     // no 1.5x in 15 min -> exit
  FLOOR_TRAIL: 0.65,           // after 2x: sell the rest if it falls 35% from its high
  FLOOR_TG_PER_HOUR: 4,        // Telegram max 4 floor alerts per hour (only coins from a dev with an earlier graduated coin)
  FLOOR_CP_SEC: [60, 120, 180, 240],  // v11.4: clean study snapshots at these ages
  GOOD_DEV_BONUS: 8,
  // v11.5 "one decision" Telegram
  TG_DAILY_BUYS: Number(process.env.TG_DAILY_BUYS || 20),   // v12.1: up to 20 "🟢 வாங்கு" a day
  TG_MIN_GAP_MIN: Number(process.env.TG_MIN_GAP_MIN || 60), // v12.1: at least 60 minutes between two          // v11.9: after one "🟢 வாங்கு", wait at least 90 minutes before the next one            // at most 3 "🟢 வாங்கு" messages per day (A grade only); 💰 / 🔴 come as replies
  TG_SUMMARY_HOUR: 23,         // nightly summary at 11 PM (laptop time)
  // v11.5 🚀 graduation watch (data: instant-graduation coins -> 21% were $100K+ one hour later, slow ones 8%)
  GRAD_INSTANT_SEC: 120,       // curve filled within 2 minutes of creation
  GRAD_WATCH_MIN: 60,          // follow every graduated coin on DexScreener for 60 minutes (1 call per 30 coins per minute)
  ROCKET_FROM_MIN: 3, ROCKET_TO_MIN: 15,   // entry window after graduation
  ROCKET_MIN_USD: 35000, ROCKET_MAX_USD: 120000, ROCKET_MIN_LIQ: 8000,
  ROCKET_FOLLOW_H: 6,
  // v11.7 own "smart money" ledger: real profit / loss of every wallet from every pump.fun trade we see
  PRO_MIN_TRADES: 10,          // closed trades in the last 7 days
  PRO_MIN_WINRATE: 0.45, PRO_MAX_WINRATE: 0.9,
  PRO_MIN_PNL_SOL: 3,          // made at least 3 SOL
  PRO_MIN_HOLD_SEC: 300,       // average hold 5+ minutes (bots / insiders flip in seconds)
  PRO_MAX_TRADES_DAY: 100,
  PRO_SIGNAL_WALLETS: 2,       // 2+ pro wallets buy the same coin within 2 minutes
  PRO_SIGNAL_MAX_USD: 12000,
  PRO_TG_MIN_HOURS: 72,        // Telegram only after 3 days of ledger data and 20+ pro wallets          // paper trade followed for 6 hours           // v11.4: dev launched a coin that graduated before (data: 9.5% graduate vs 4% for new devs)
  // v11.3 bots + smart-wallet alert limits
  BOT_MINTS_PER_HOUR: 15,      // a wallet that buys 15+ different coins in an hour is a bot, never "smart"
  SMART_ALERT_MIN_USD: 8000,
  SMART_ALERT_MIN_AGE_SEC: 300,
  SMART_ALERT_MIN_HOLDERS: 20,
  SMART_ALERT_PER_HOUR: 5,
  MAX_ONE_WALLET_BUY_SHARE: 0.5, // one wallet must not be >50% of 5-min buy SOL
  DUMP_FROM_PEAK: 0.45,        // fell below 45% of its peak -> DUMPED forever
  SERIAL_DEV_24H: 3,           // dev launched 3+ coins in 24h -> reject
  SIGNAL_SCORE: 60,            // score needed for BUY SIGNAL (backtest: winners scored ~60-75)
  HOT_SCORE: 75,               // (kept for advanced page) HOT = 4+ stars and smart money or trending name
  WATCH_SCORE: 45,             // score needed for WATCH list
  SMART_MIN_WINS: 2,           // smart wallet: at least 2 early wins
  SMART_MIN_RATE: 0.35,        // ... and win rate >= 35%
  WIN_MULTIPLE: 3,             // a wallet "wins" if coin later went 3x from its buy
  GRADUATION_VSOL: 113,        // bonding curve almost complete (~115 vSOL)
  EXIT_WARN_FROM_MAX: 0.6,     // after signal: fell below 60% of its high -> EXIT WARNING
  MAX_DEV_LINKED_PCT: 5,       // wallets funded by the dev (or dev's funder) may hold max 5%
  MAX_DEV_LINKED_WALLETS: 3,   // ... and at most 3 such wallets
  MAX_FAMILY_PCT: 20,          // one "mother" wallet's children may hold max 20%
  INTEL_WAIT_MS: 20000,        // wait up to 20s for the wallet check before signalling
  FALLBACK_SOL_USD: 180,       // used only if live SOL price fails
};

const TOKEN_SUPPLY = 1_000_000_000;
const SIGNALS_FILE = path.join(__dirname, "signals.jsonl");
const OUTCOMES_FILE = path.join(__dirname, "signal_outcomes.jsonl");
const SMART_FILE = path.join(__dirname, "smart_wallets.json");
const DEVS_FILE = path.join(__dirname, "dev_history.json");
const FAMILY_FILE = path.join(__dirname, "smart_families.json");
const CHECKPOINTS_MIN = [5, 15, 30, 60, 180];
const ZONE_FILE = path.join(__dirname, "zone_history.jsonl");
const LEVELS_USD = [5000, 10000, 25000, 40000];
const ARCHIVE_FILE = path.join(__dirname, "signals_archive.json");
const MYW_FILE = path.join(__dirname, "my_wallets.txt");
const TRUE_FILE = path.join(__dirname, "true_outcomes.jsonl");
const OQ_FILE = path.join(__dirname, "outcome_queue.json");
let myWallets = new Map();           // wallet -> name (my_wallets.txt)
const smartFeed = [];                // recent buys/sells by smart / my wallets
const smartCoins = new Map();        // mint -> {wallets:Map, alerted, symbol}
const revival = new Map();           // untracked mint -> {buyers:Map(wallet->t), trades:[], lastMc, first}
const FLOOR_FILE = path.join(__dirname, "floor_trades.jsonl");
const SHADOW_FILE = path.join(__dirname, "floor_shadow.jsonl");
const CP_FILE = path.join(__dirname, "floor_cp.jsonl");
const GRAD_FILE = path.join(__dirname, "grad_track.jsonl");
const ROCKET_FILE = path.join(__dirname, "rocket_trades.jsonl");
const TG_FILE = path.join(__dirname, "tg_state.json");
let gradList = [];                   // graduated coins being followed on DexScreener
let rocketArchived = [];
let tgState = { day: null, buys: 0, summaryDay: null, sent: [] };
const LEDGER_FILE = path.join(__dirname, "wallet_ledger.json");
const PATH_FILE = path.join(__dirname, "signal_paths.jsonl");     // v12: minute-by-minute price after every signal
const TREND_FILE = path.join(__dirname, "trend_track.jsonl");     // v12: GeckoTerminal trending tokens, followed 6h
let trendList = [];                                               // [{mint, pool, firstAt, rank, entry, path:[]}]
const trendSeen = new Set();
const PRO_FILE = path.join(__dirname, "pro_trades.jsonl");
let ledger = { started: null, w: {} };   // wallet -> {n, win, pnl, hold, days:{d:count}, last}
const positions = new Map();            // wallet|mint -> {b, s, bt, st, at, mc}
const lastMc = new Map();               // mint -> {mc, t}
const proBuys = new Map();              // mint -> Map(wallet -> t)
let proSet = new Set();                 // qualified pro wallets (refreshed every 5 min)
let proArchived = [];
let ledgerSaves = 2;   // first maintain call saves
const botSeen = new Map();           // wallet -> Map(mint -> t)  (buys in the last hour)
const floorList = [];                // mints with a floor signal (newest first)
let floorArchived = [];
const tgTimes = { floor: [], smart: [] };
let outcomeQueue = [];               // [{mint, symbol, gradAt, done:{1:mc,...}}]
let archived = [];   // signals from before a restart (results tab survives restarts)
const DEX_API = "https://api.dexscreener.com/token-pairs/v1/solana/";

const coins = new Map();          // mint -> state
const pending = new Map();        // trades that arrived before the create event
const recentSignals = [];         // newest first
const counters = { created: 0, trades: 0, signals: 0, hot: 0, rejectedForever: 0 };
const foreverReasons = {};        // kind -> count
const tradeTimes = [];            // for trades/min
let lastTradeAt = null;
let solUsd = CFG.FALLBACK_SOL_USD;
let solUsdSource = "FALLBACK";
let timers = [];

// learned memory (saved to disk)
let smart = new Map();            // wallet -> {w, l, last}
let devs = new Map();             // creator -> [{mint, symbol, t, result}]
let families = new Map();         // funder ("mother") wallet -> {w, l, last}
let kols = new Set();             // optional kol_wallets.txt
const narr = new Map();           // name word -> [{mint, t}]
const KOL_FILE = path.join(__dirname, "kol_wallets.txt");
const STOP_WORDS = new Set(["the","coin","token","sol","solana","pump","fun","inu","meme","official","of","and","for","new","bonk","pumpfun","ai","on","in","to","is","it","my","a","an","x"]);

const BACKTEST = () => process.env.EARLYWHALE_BACKTEST === "1";
const nowMs = () => Date.now();
const iso = ms => new Date(ms).toISOString();
const r2 = n => Math.round(n * 100) / 100;
const clamp01 = x => Math.max(0, Math.min(1, x));
function append(file, obj) {
  if (BACKTEST()) return;
  try { fs.appendFileSync(file, JSON.stringify(obj) + "\n", "utf8"); }
  catch (e) { console.error("[SIGNAL LOG]", e.message); }
}

// ---------------- persistence ----------------
function loadMemory() {
  try {
    const s = JSON.parse(fs.readFileSync(SMART_FILE, "utf8"));
    smart = new Map(Object.entries(s));
  } catch (_) { /* first run */ }
  try {
    const d = JSON.parse(fs.readFileSync(DEVS_FILE, "utf8"));
    devs = new Map(Object.entries(d));
  } catch (_) { /* first run */ }
  try {
    families = new Map(Object.entries(JSON.parse(fs.readFileSync(FAMILY_FILE, "utf8"))));
  } catch (_) { /* first run */ }
  try {
    kols = new Set(fs.readFileSync(KOL_FILE, "utf8").split(/\r?\n/).map(l => l.replace(/#.*/, "").trim().split(/[\s,|]+/)[0]).filter(x => x && x.length >= 32 && x.length <= 44));
    if (kols.size) console.log(`[SIGNAL ENGINE] KOL list: ${kols.size} wallets`);
  } catch (_) { /* optional */ }
  try {
    myWallets = new Map();
    for (const line of fs.readFileSync(MYW_FILE, "utf8").split(/\r?\n/)) {
      const addr = line.replace(/#.*/, "").trim().split(/[\s,|]+/)[0];
      if (!addr || addr.length < 32 || addr.length > 44) continue;
      const name = (line.split("#")[1] || "").trim() || addr.slice(0, 4) + "…" + addr.slice(-4);
      myWallets.set(addr, name);
    }
    if (myWallets.size) console.log(`[SIGNAL ENGINE] my wallets: ${myWallets.size}`);
  } catch (_) { /* optional */ }
  try { outcomeQueue = JSON.parse(fs.readFileSync(OQ_FILE, "utf8")); } catch (_) { outcomeQueue = []; }
  console.log(`[SIGNAL ENGINE] memory: ${smart.size} wallets, ${devs.size} devs`);
}

function saveMemory() {
  if (BACKTEST()) return;
  try {
    const cutoff = nowMs() - 7 * 24 * 3600 * 1000;
    for (const [k, v] of devs) {
      const kept = v.filter(x => x.t > cutoff);
      if (kept.length) devs.set(k, kept.slice(-20)); else devs.delete(k);
    }
    if (smart.size > 20000) {
      const arr = [...smart.entries()].sort((a, b) => (b[1].w * 2 - b[1].l) - (a[1].w * 2 - a[1].l));
      smart = new Map(arr.slice(0, 15000));
    }
    fs.writeFileSync(SMART_FILE, JSON.stringify(Object.fromEntries(smart)));
    fs.writeFileSync(DEVS_FILE, JSON.stringify(Object.fromEntries(devs)));
    if (families.size > 20000) families = new Map([...families.entries()].sort((a, b) => (b[1].w * 2 - b[1].l) - (a[1].w * 2 - a[1].l)).slice(0, 15000));
    fs.writeFileSync(FAMILY_FILE, JSON.stringify(Object.fromEntries(families)));
  } catch (e) { console.error("[SIGNAL MEMORY]", e.message); }
}

function isBot(wallet) {
  const m = botSeen.get(wallet);
  return !!m && m.size >= CFG.BOT_MINTS_PER_HOUR;
}
function noteBuyer(wallet, mint, at) {
  if (!wallet) return;
  let m = botSeen.get(wallet);
  if (!m) { if (botSeen.size > 400000) return; m = new Map(); botSeen.set(wallet, m); }
  m.set(mint, at);
}
function tgAllowed(kind, perHour) {
  const at = nowMs();
  const list = tgTimes[kind];
  while (list.length && at - list[0] > 3600 * 1000) list.shift();
  if (list.length >= perHour) return false;
  list.push(at);
  return true;
}

// ---------------- v11.7 wallet ledger ----------------
function ledgerTrade(t) {
  const w = t.traderPublicKey; if (!w || !t.mint) return;
  const at = nowMs(), sol = Number(t.solAmount) || 0, tok = Number(t.tokenAmount) || 0;
  if (Number.isFinite(t.marketCapSol) && t.marketCapSol > 0) lastMc.set(t.mint, { mc: t.marketCapSol, t: at });
  const key = w + "|" + t.mint;
  let p = positions.get(key);
  if (t.txType === "buy") {
    if (!p) { if (positions.size > 400000) return; p = { b: 0, s: 0, bt: 0, st: 0, at, mc: t.marketCapSol || null }; positions.set(key, p); }
    p.b += sol; p.bt += tok;
  } else if (p) {
    p.s += sol; p.st += tok;
    if (p.bt > 0 && p.st >= 0.9 * p.bt) { positions.delete(key); ledgerClose(w, p, at); }
  }
}
function ledgerClose(w, p, at) {
  if (p.b < 0.01) return;                       // dust
  const pnl = p.s - p.b;
  let L = ledger.w[w];
  if (!L) { L = ledger.w[w] = { n: 0, win: 0, pnl: 0, hold: 0, days: {}, last: 0, recent: [] }; }
  L.n++; if (pnl > 0) L.win++; L.pnl = Math.round((L.pnl + pnl) * 1000) / 1000; L.hold += Math.min(86400, (at - p.at) / 1000); L.last = at;
  const d = localDay(); L.days[d] = (L.days[d] || 0) + 1;
  L.recent.push([Math.round(at / 1000), Math.round(pnl * 1000) / 1000, Math.round((at - p.at) / 1000)]);
  if (L.recent.length > 30) L.recent.shift();
}
function ledgerMaintain() {
  const at = nowMs();
  if (!ledger.started) ledger.started = at;
  // positions held 6h+ : count at last known price (mark-to-market)
  for (const [key, p] of positions) {
    if (at - p.at < 6 * 3600 * 1000) continue;
    const mint = key.split("|")[1], lm = lastMc.get(mint);
    const val = lm && p.bt > 0 ? (p.bt - p.st) * (lm.mc / TOKEN_SUPPLY) : 0;
    positions.delete(key);
    ledgerClose(key.split("|")[0], { ...p, s: p.s + val }, at);
  }
  for (const [mint, v] of lastMc) if (at - v.t > 7 * 3600 * 1000) lastMc.delete(mint);
  // keep only last 7 days per wallet; drop tiny wallets
  const cut = at / 1000 - 7 * 86400;
  for (const [w, L] of Object.entries(ledger.w)) {
    L.recent = L.recent.filter(r => r[0] >= cut);
    if (!L.recent.length && at - L.last > 7 * 86400 * 1000) delete ledger.w[w];
  }
  const all = Object.entries(ledger.w);
  if (all.length > 60000) {
    all.sort((a, b) => (b[1].recent.length - a[1].recent.length) || (b[1].last - a[1].last));
    ledger.w = Object.fromEntries(all.slice(0, 50000));
  }
  // qualified pro wallets
  const next = new Set();
  for (const [w, L] of Object.entries(ledger.w)) {
    const r = L.recent; if (r.length < CFG.PRO_MIN_TRADES) continue;
    const wins = r.filter(x => x[1] > 0).length, pnl = r.reduce((a, x) => a + x[1], 0), hold = r.reduce((a, x) => a + x[2], 0) / r.length;
    const perDay = Math.max(...Object.values(L.days));
    const wr = wins / r.length;
    if (wr >= CFG.PRO_MIN_WINRATE && wr <= CFG.PRO_MAX_WINRATE && pnl >= CFG.PRO_MIN_PNL_SOL && hold >= CFG.PRO_MIN_HOLD_SEC && perDay <= CFG.PRO_MAX_TRADES_DAY && !isBot(w)) next.add(w);
  }
  proSet = next;
  for (const L of Object.values(ledger.w)) { const ks = Object.keys(L.days).sort(); while (ks.length > 8) delete L.days[ks.shift()]; }
  ledgerSaves = (ledgerSaves + 1) % 3;
  if (!BACKTEST() && ledgerSaves === 0) try { fs.writeFileSync(LEDGER_FILE, JSON.stringify(ledger)); } catch (e) { console.error("[LEDGER]", e.message); }
}
function loadLedger() { try { ledger = JSON.parse(fs.readFileSync(LEDGER_FILE, "utf8")); ledger.w ||= {}; } catch (_) { ledger = { started: null, w: {} }; } }
function proStats(w) {
  const L = ledger.w[w]; if (!L) return null;
  const r = L.recent, wins = r.filter(x => x[1] > 0).length;
  return { n: r.length, wr: r.length ? Math.round(wins / r.length * 100) : 0, pnl: Math.round(r.reduce((a, x) => a + x[1], 0) * 10) / 10, hold: r.length ? Math.round(r.reduce((a, x) => a + x[2], 0) / r.length / 60) : 0 };
}
function proBuy(t) {
  if (t.txType !== "buy" || !proSet.has(t.traderPublicKey)) return;
  const at = nowMs();
  let m = proBuys.get(t.mint); if (!m) { m = new Map(); proBuys.set(t.mint, m); }
  m.set(t.traderPublicKey, at);
  for (const [w, wt] of m) if (at - wt > 120000) m.delete(w);
  const c = coins.get(t.mint);
  if (!c || c.pro || m.size < CFG.PRO_SIGNAL_WALLETS || c.mcapSol === null) return;
  const usd = c.mcapSol * solUsd;
  if (c.mcapSol < 0.95 * CFG.FLOOR_SOL || usd > CFG.PRO_SIGNAL_MAX_USD || c.forever) return;
  const ws = [...m.keys()];
  c.pro = { at: iso(at), atMs: at, entryMcapSol: c.mcapSol, entryUsd: Math.round(usd), wallets: ws.map(w => ({ w: w.slice(0, 4) + "…" + w.slice(-4), ...proStats(w) })),
    maxX: 1, nowX: 1, minX: 1, tp1: false, tp2: false, cash: 0, rem: 1, pnl: 0, closed: false, reason: null };
  append(PRO_FILE, { type: "PRO_SIGNAL", timestamp: iso(at), mint: c.mint, symbol: c.symbol, mcapUsd: Math.round(usd), wallets: c.pro.wallets });
  if (!BACKTEST()) console.log(`[PRO] ${c.symbol} $${Math.round(usd)} ${ws.length} pro wallets`);
  const ready = ledger.started && at - ledger.started >= CFG.PRO_TG_MIN_HOURS * 3600 * 1000 && proSet.size >= 20;
  if (ready) tgDecisionBuy(c.pro,
    `👛 ${ws.length} லாபகரமான வாலெட்கள் 2 நிமிடத்தில் வாங்கின — ${c.symbol}\n` +
    `மார்க்கெட் கேப் $${(usd / 1000).toFixed(1)}K\n` +
    c.pro.wallets.map(x => `• ${x.w}: 7 நாளில் ${x.n} trade, ${x.wr}% வெற்றி, +${x.pnl} SOL`).join("\n") + "\n" +
    `திட்டம் (GMGN TP/SL): 2x-இல் பாதி · 4x-இல் மீதியில் பாதி · -50%-இல் எல்லாம்\nhttps://gmgn.ai/sol/token/${c.mint}`, true, "pro", c.symbol);
}
function proStep(c, at) {
  const r = c.pro; if (!r || r.closed || !c.mcapSol) return;
  const x = c.mcapSol / r.entryMcapSol;
  r.nowX = r2(x); if (x > r.maxX) r.maxX = r2(x); if (x < r.minX) r.minX = r2(x);
  const close = reason => {
    r.cash += r.rem * x; r.rem = 0; r.closed = true; r.reason = reason;
    r.pnl = r2(r.cash * (1 - CFG.FEE_ROUND_TRIP / 2) / (1 + CFG.FEE_ROUND_TRIP / 2) - 1);
    append(PRO_FILE, { type: "PRO_CLOSE", timestamp: iso(at), mint: c.mint, symbol: c.symbol, reason, exitX: r2(x), maxX: r.maxX, pnl: r.pnl });
    if (reason === "STOP") tgFollow(r, `🔴 முழுவதும் விற்கவும் — ${c.symbol} (பாதியாக விழுந்தது)`);
  };
  if (!r.tp1 && x >= 2) { r.tp1 = true; r.cash += 1; r.rem = 0.5; tgFollow(r, `💰 2x — ${c.symbol}: பாதியை விற்கவும்`); }
  if (r.tp1 && !r.tp2 && x >= 4) { r.tp2 = true; r.cash += 1; r.rem = 0.25; tgFollow(r, `💰 4x — ${c.symbol}: மீதியில் பாதியை விற்கவும்`); }
  if (x <= 0.5) return close("STOP");
  if (c.graduated) return close("GRADUATED");
  if ((at - r.atMs) / 60000 >= 120) return close("END");
  r.pnl = r2((r.cash + r.rem * x) * (1 - CFG.FEE_ROUND_TRIP / 2) / (1 + CFG.FEE_ROUND_TRIP / 2) - 1);
}

function isSmart(wallet) {
  if (myWallets.has(wallet)) return true;
  if (proSet.has(wallet)) return true;
  if (isBot(wallet)) return false;
  if (kols.has(wallet)) return true;
  const s = smart.get(wallet);
  if (!s) return false;
  const rate = s.w / Math.max(1, s.w + s.l);
  return s.w >= CFG.SMART_MIN_WINS && rate >= CFG.SMART_MIN_RATE;
}

// ---------------- Trending names ("narratives") ----------------
function nameWords(c) {
  const raw = `${c.symbol || ""} ${c.name || ""}`.toLowerCase().normalize("NFKD");
  const words = raw.split(/[^a-z0-9]+/).filter(w => w.length >= 3 && !STOP_WORDS.has(w) && !/^\d+$/.test(w));
  return [...new Set(words)].slice(0, 6);
}
function registerNarrative(c) {
  const t = nowMs();
  for (const w of nameWords(c)) {
    const list = narr.get(w) || [];
    list.push({ mint: c.mint, t });
    narr.set(w, list.slice(-200));
  }
}
function narrativeOf(c) {
  const at = nowMs();
  let best = null;
  for (const w of nameWords(c)) {
    const list = (narr.get(w) || []).filter(x => at - x.t <= 3600 * 1000);
    if (!best || list.length > best.count) best = { word: w, count: list.length, mints: list.map(x => x.mint) };
  }
  if (!best || best.count < 4) return null;
  let leader = null, leaderHolders = -1;
  for (const mint of best.mints) {
    const o = coins.get(mint);
    const h = o?.holderNow ?? 0;
    if (o && h > leaderHolders) { leaderHolders = h; leader = mint; }
  }
  return { word: best.word, count: best.count, leader: leader === c.mint };
}

function isSmartFamily(funder) {
  const s = families.get(funder);
  if (!s) return false;
  return s.w >= CFG.SMART_MIN_WINS && s.w / Math.max(1, s.w + s.l) >= CFG.SMART_MIN_RATE;
}

// Ask the wallet-intelligence module (Helius) about this coin's first buyers.
function requestIntel(c) {
  if (BACKTEST()) return;
  c.intel = { ...(c.intel || {}), status: c.intel?.status === "DONE" ? "DONE" : "PENDING", requestedAt: nowMs(), running: true };
  intel.analyzeCoin(c, { isSmart, isSmartFamily }, TOKEN_SUPPLY)
    .then(r => { c.intel = { ...r, requestedAt: c.intel.requestedAt, running: false }; })
    .catch(e => { c.intel = { status: "ERROR", reason: e.message, requestedAt: c.intel.requestedAt, running: false }; });
}

function devInfo(creator) {
  const list = (creator && devs.get(creator)) || [];
  const day = nowMs() - 24 * 3600 * 1000;
  return {
    launches24h: list.filter(x => x.t > day).length,
    launchesTotal: list.length,
    rugs: list.filter(x => x.result === "RUG_DEV" || x.result === "DUMPED").length,
    graduated: list.filter(x => x.result === "GRADUATED").length,
    pumped: list.filter(x => x.result === "PUMPED").length,
    closed: list.filter(x => x.result && x.result !== "OPEN").length,
    faded: list.filter(x => x.result === "FADED").length,
  };
}

// ---------------- SOL price ----------------
async function refreshSolPrice() {
  const sources = [
    ["BINANCE", "https://api.binance.com/api/v3/ticker/price?symbol=SOLUSDT", j => Number(j.price)],
    ["COINGECKO", "https://api.coingecko.com/api/v3/simple/price?ids=solana&vs_currencies=usd", j => Number(j?.solana?.usd)],
  ];
  for (const [name, url, pick] of sources) {
    try {
      const res = await fetch(url, { signal: AbortSignal.timeout(8000) });
      if (!res.ok) continue;
      const p = pick(await res.json());
      if (Number.isFinite(p) && p > 1) { solUsd = p; solUsdSource = name; return; }
    } catch (_) { /* try next */ }
  }
}

// ---------------- Telegram (optional) ----------------
// v11.5: links open GMGN directly, and the contract address is tap-to-copy (paste into the GMGN bot / app)
function tgFormat(text) {
  const esc = String(text).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  return esc.replace(/https:\/\/(?:pump\.fun\/coin|gmgn\.ai\/sol\/token)\/([1-9A-HJ-NP-Za-km-z]{32,44}|[A-Za-z0-9_]+)/g,
    (_, mint) => `<a href="https://gmgn.ai/sol/token/${mint}">👉 GMGN-இல் திற</a>\n📋 <code>${mint}</code>`);
}
async function sendTelegram(text, replyTo) {
  if (BACKTEST()) return null;
  const token = (process.env.TELEGRAM_BOT_TOKEN || "").trim();
  const chat = (process.env.TELEGRAM_CHAT_ID || "").trim();
  if (!token || !chat) return null;
  try {
    const res = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chat, text: tgFormat(text), parse_mode: "HTML", disable_web_page_preview: true, ...(replyTo ? { reply_to_message_id: replyTo, allow_sending_without_reply: true } : {}) }),
      signal: AbortSignal.timeout(10000),
    });
    const j = await res.json().catch(() => null);
    return j?.result?.message_id || null;
  } catch (e) { console.error("[TELEGRAM]", e.message); return null; }
}
// v11.5: "one decision" mode (default). TG_MODE=all in .env brings back every message.
const DECISION = () => (process.env.TG_MODE || "decision").trim() !== "all";
const localDay = () => { const d = new Date(nowMs()); return d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d.getDate(); };
function loadTg() { try { tgState = { ...tgState, ...JSON.parse(fs.readFileSync(TG_FILE, "utf8")) }; } catch (_) {} }
function saveTg() { if (!BACKTEST()) try { fs.writeFileSync(TG_FILE, JSON.stringify(tgState)); } catch (_) {} }
// holder = the coin (main signal), its floor trade or its rocket trade. Sends at most TG_DAILY_BUYS per day.
function tgDecisionBuy(holder, text, isA, kind, symbol) {
  if (BACKTEST()) return;
  if (!DECISION()) { holder.telegram = true; void sendTelegram(text).then(id => { holder.tgMsgId = id; }); return; }
  if (!isA) return;
  const d = localDay();
  if (tgState.day !== d) { tgState.day = d; tgState.buys = 0; tgState.sent = []; }
  if (tgState.buys >= CFG.TG_DAILY_BUYS) return;
  if (tgState.lastBuyAt && nowMs() - tgState.lastBuyAt < CFG.TG_MIN_GAP_MIN * 60000) return;
  tgState.buys++;
  tgState.lastBuyAt = nowMs();
  holder.telegram = true;
  tgState.sent.push({ kind, symbol, t: nowMs() });
  saveTg();
  void sendTelegram(`🟢 வாங்கு (இன்று ${tgState.buys}/${CFG.TG_DAILY_BUYS})\n` + text).then(id => { holder.tgMsgId = id; });
}
function tgFollow(holder, text) {
  if (BACKTEST()) return;
  if (!DECISION()) { void sendTelegram(text); return; }
  if (holder && holder.telegram) void sendTelegram(text, holder.tgMsgId);
}

// ---------------- Social metadata (twitter / telegram / website / image) ----------------
function ipfsToHttp(u) {
  if (!u || typeof u !== "string") return null;
  if (u.startsWith("ipfs://")) return "https://ipfs.io/ipfs/" + u.slice(7);
  return /^https?:\/\//i.test(u) ? u : null;
}

async function fetchSocial(c) {
  c.social = { status: "LOADING" };
  const url = ipfsToHttp(c.uri);
  if (!url) { c.social = { status: "NO_METADATA" }; return; }
  try {
    const res = await fetch(url, { signal: AbortSignal.timeout(8000) });
    if (!res.ok) throw new Error("HTTP " + res.status);
    const j = await res.json();
    const pick = v => (typeof v === "string" && /^https?:\/\//i.test(v.trim()) ? v.trim() : null);
    const twitter = pick(j.twitter) || pick(j?.extensions?.twitter);
    const telegram = pick(j.telegram) || pick(j?.extensions?.telegram);
    const website = pick(j.website) || pick(j?.extensions?.website);
    c.social = {
      status: "OK", twitter, telegram, website,
      image: ipfsToHttp(j.image),
      description: typeof j.description === "string" ? j.description.slice(0, 280) : "",
      count: [twitter, telegram, website].filter(Boolean).length,
    };
  } catch (e) {
    c.social = { status: "ERROR", reason: e.message };
  }
}

// ---------------- Input: create ----------------
function onCreate({ mint, symbol, name, creator, uri }) {
  if (!mint) return;
  const existing = coins.get(mint);
  if (existing) {
    if (!existing.uri && uri) existing.uri = uri;
    if (!existing.creator && creator) existing.creator = creator;
    return;
  }
  const at = nowMs();
  const dev = devInfo(creator);
  const c = {
    mint,
    symbol: symbol || "UNKNOWN",
    name: name || "UNKNOWN",
    creator: creator || null,
    uri: uri || null,
    createdAt: at,
    launchTs: null,
    startMcapSol: null, mcapSol: null, peakMcapSol: 0, vSol: null,
    lastTradeAt: null,
    trades: [],
    wallets: new Map(),        // wallet -> {net, buySol, sellSol, firstTs, entryMcap, order}
    buyers: new Set(),
    buyOrder: 0,
    tradeCount: 0,
    devBought: 0, devSold: 0,
    dev,
    history: [],
    status: "NEW", score: 0, reasons: [], metrics: null,
    forever: null, foreverKind: null,
    social: null,
    signal: null, outcome: null, graduated: false,
    holderHist: [], holderNow: 0, peakHolders: 0, readyAt: null, entryType: null,
  };
  coins.set(mint, c);
  counters.created++;
  registerNarrative(c);

  if (creator) {
    const list = devs.get(creator) || [];
    list.push({ mint, symbol: c.symbol, t: at, result: "OPEN" });
    devs.set(creator, list.slice(-200));
  }

  const buffered = pending.get(mint);
  if (buffered) {
    pending.delete(mint);
    for (const t of buffered.trades) applyTrade(c, t);
  }
}

// ---------------- Input: trade ----------------
function onTrade(t) {
  if (!t || !t.mint) return;
  counters.trades++;
  lastTradeAt = nowMs();
  tradeTimes.push(lastTradeAt);
  if (tradeTimes.length > 20000) tradeTimes.splice(0, tradeTimes.length - 20000);

  const wallet = t.traderPublicKey;
  if (t.txType === "buy") noteBuyer(wallet, t.mint, lastTradeAt);
  ledgerTrade(t);
  if (wallet && (myWallets.has(wallet) || isSmart(wallet))) noteSmart(t);

  const c = coins.get(t.mint);
  if (c) return applyTrade(c, t);
  trackRevival(t);

  let p = pending.get(t.mint);
  if (!p) { p = { at: nowMs(), trades: [] }; pending.set(t.mint, p); }
  if (p.trades.length < 300) p.trades.push(t);
}

function applyTrade(c, t) {
  const at = nowMs();
  const side = t.txType;
  const sol = Number(t.solAmount) || 0;
  const tok = Number(t.tokenAmount) || 0;
  const wallet = t.traderPublicKey || "UNKNOWN";
  const ts = Number(t.eventTimestamp) || Math.floor(at / 1000);

  if (c.launchTs === null) c.launchTs = ts;
  if (Number.isFinite(t.marketCapSol) && t.marketCapSol > 0) {
    c.mcapSol = t.marketCapSol;
    if (c.startMcapSol === null) c.startMcapSol = t.marketCapSol;
  }
  if (Number.isFinite(t.vSolInBondingCurve)) c.vSol = t.vSolInBondingCurve;
  if (c.mcapSol > c.peakMcapSol) c.peakMcapSol = c.mcapSol;
  c.lastTradeAt = at;
  c.tradeCount++;

  let w = c.wallets.get(wallet);
  if (!w) {
    w = { net: 0, buySol: 0, sellSol: 0, boughtTok: 0, soldTok: 0, firstTs: ts, firstAt: at, entryMcap: null, order: null };
    c.wallets.set(wallet, w);
  }

  if (side === "buy") {
    w.net += tok; w.buySol += sol; w.boughtTok += tok; c.buyers.add(wallet);
    if (w.order === null) { w.order = c.buyOrder++; w.entryMcap = c.mcapSol; w.firstAt = at; }
    if (wallet === c.creator) c.devBought += tok;
  } else if (side === "sell") {
    w.net = Math.max(0, w.net - tok); w.sellSol += sol; w.soldTok += tok;
    if (wallet === c.creator) c.devSold += tok;
  }

  c.trades.push({ t: at, side, sol, wallet, mc: c.mcapSol, ts });
  if (c.trades.length > 4000) c.trades.splice(0, c.trades.length - 4000);

  if (c.vSol !== null && c.vSol >= CFG.GRADUATION_VSOL && !c.graduated) { c.graduated = true; queueOutcome(c); }
  if (c.signal) updateOutcome(c);
  if (c.floorSnap && c.mcapSol) { if (c.mcapSol > c.floorSnap.maxMc) { c.floorSnap.maxMc = c.mcapSol; c.floorSnap.maxAt = at; } if (c.mcapSol < c.floorSnap.minMc) c.floorSnap.minMc = c.mcapSol;
    if (!c.floorSnap.hit2At && c.mcapSol >= 2 * c.floorSnap.mc) c.floorSnap.hit2At = at;
    if (!c.floorSnap.hit07At && c.mcapSol <= 0.7 * c.floorSnap.mc) c.floorSnap.hit07At = at; }
  if (c.floor && !c.floor.closed) floorStep(c, at);
  proBuy(t);
  if (c.pro && !c.pro.closed) proStep(c, at);
  if (c.floorCps && c.mcapSol) for (const p of c.floorCps) {
    if (p.skip) continue;
    if (c.mcapSol > p.maxMc) { p.maxMc = c.mcapSol; p.maxAt = at; }
    if (c.mcapSol < p.minMc) p.minMc = c.mcapSol;
    if (!p.hit2At && c.mcapSol >= 2 * p.mc) p.hit2At = at;
    if (!p.hit07At && c.mcapSol <= 0.7 * p.mc) p.hit07At = at;
  }
}

const DUST = 1000; // tokens; below this a wallet is not counted as a holder
function holderCount(c) {
  let n = 0;
  for (const w of c.wallets.values()) if (w.net > DUST) n++;
  return n;
}

// ---------------- Smart / my wallets activity ----------------
function noteSmart(t) {
  const at = nowMs();
  const usd = Number.isFinite(t.marketCapSol) ? Math.round(t.marketCapSol * solUsd) : null;
  const c = coins.get(t.mint);
  const ev = { t: at, wallet: t.traderPublicKey, name: myWallets.get(t.traderPublicKey) || null, mine: myWallets.has(t.traderPublicKey),
    mint: t.mint, symbol: c?.symbol || null, side: t.txType, sol: Math.round((Number(t.solAmount) || 0) * 100) / 100, mcapUsd: usd };
  smartFeed.unshift(ev);
  if (smartFeed.length > 300) smartFeed.pop();
  if (t.txType !== "buy") return;
  let sc = smartCoins.get(t.mint);
  if (!sc) { sc = { wallets: new Map(), alerted: false, symbol: ev.symbol, first: at }; smartCoins.set(t.mint, sc); }
  sc.wallets.set(t.traderPublicKey, at);
  if (ev.symbol) sc.symbol = ev.symbol;
  sc.mcapUsd = usd;
  for (const [w, wt] of sc.wallets) if (at - wt > 10 * 60000) sc.wallets.delete(w);
}

// Holders must climb minute by minute (organic), not jump in one burst (bots).
function holderStairs(c, at) {
  const pts = [];
  for (let k = 5; k >= 0; k--) {
    const target = at - k * 60000;
    let best = null;
    for (const h of c.holderHist) if (h.t <= target + 5000 && (!best || h.t > best.t)) best = h;
    pts.push(best ? best.n : null);
  }
  if (pts.some(x => x === null)) return { ok: false, pts };
  let up = 0, maxStep = 0;
  for (let i = 1; i < pts.length; i++) { const d = pts[i] - pts[i - 1]; if (d > 0) up++; if (d > maxStep) maxStep = d; }
  const total = pts[5] - pts[0];
  return { ok: total >= 5 && up >= 4 && maxStep <= total * 0.5, pts, total };
}

function smartAlertCheck(at) {
  for (const [mint, sc] of smartCoins) {
    if (sc.alerted) continue;
    const c = coins.get(mint);
    if (!c || c.forever || c.mcapSol === null) continue;
    const holding = [...sc.wallets.keys()].filter(w => !isBot(w) && (c.wallets.get(w)?.net || 0) > DUST);
    if (holding.length < CFG.SMART_ALERT_WALLETS) continue;
    const usd = c.mcapSol * solUsd;
    if (usd < CFG.SMART_ALERT_MIN_USD || usd > CFG.SMART_ALERT_MAX_USD) continue;
    if ((at - c.createdAt) / 1000 < CFG.SMART_ALERT_MIN_AGE_SEC) continue;
    if ((c.holderNow || 0) < CFG.SMART_ALERT_MIN_HOLDERS) continue;
    const st = holderStairs(c, at);
    if (!st.ok) continue;
    sc.alerted = true;
    sc.passed = true;
    const names = holding.map(w => myWallets.get(w) || (w.slice(0, 4) + "…")).join(", ");
    if (!BACKTEST()) console.log(`[SMART] ${holding.length} smart wallets holding ${c.symbol} at $${Math.round(usd)}`);
    if (tgAllowed("smart", CFG.SMART_ALERT_PER_HOUR)) {
      if (!DECISION()) void sendTelegram(`👁 ${holding.length} ஸ்மார்ட் வாலெட்கள் வாங்கி இன்னும் வைத்திருக்கின்றன\n${c.symbol} — $${(usd / 1000).toFixed(1)}K · ஹோல்டர்கள் ${st.pts.join(" → ")} (படிப்படியாக ஏறுகிறது)\nயார்: ${names}\n(தகவல் மட்டும் - "வாங்கலாம்" சிக்னல் அல்ல)\nhttps://pump.fun/coin/${mint}`);
    }
  }
}

// ---------------- Revival: old / untracked coins that suddenly get a crowd ----------------
function trackRevival(t) {
  if (BACKTEST() || !t.mint || t.txType !== "buy") return;
  const at = nowMs();
  let r = revival.get(t.mint);
  if (!r) {
    if (revival.size > 20000) return;
    r = { buyers: new Map(), trades: [], first: at };
    revival.set(t.mint, r);
  }
  r.buyers.set(t.traderPublicKey, at);
  r.trades.push(t);
  if (r.trades.length > 400) r.trades.shift();
  r.lastAt = at;
  if (Number.isFinite(t.marketCapSol)) r.lastMc = t.marketCapSol;
  if (r.buyers.size < CFG.REVIVAL_BUYERS_5M) return;
  let recent = 0;
  for (const [, bt] of r.buyers) if (at - bt <= 300000) recent++;
  const usd = (r.lastMc || 0) * solUsd;
  if (recent >= CFG.REVIVAL_BUYERS_5M && usd >= CFG.REVIVAL_MIN_USD && usd <= CFG.ZONE_MAX_USD) {
    revival.delete(t.mint);
    onCreate({ mint: t.mint, symbol: null, name: null, creator: null, uri: null });
    const c = coins.get(t.mint);
    if (!c) return;
    c.revival = true;
    c.createdAt = at - (CFG.MIN_AGE_SEC + 60) * 1000;   // age is unknown (older coin) -> past the 5-minute rule
    for (const x of r.trades) applyTrade(c, x);
    c.symbol = c.symbol === "UNKNOWN" ? t.mint.slice(0, 6) : c.symbol;
    void fetchRevivalName(c);
    if (!BACKTEST()) console.log(`[REVIVAL] ${t.mint} - ${recent} buyers in 5 min at $${Math.round(usd)}`);
  }
}
async function fetchRevivalName(c) {
  try {
    const res = await fetch(DEX_API + c.mint, { signal: AbortSignal.timeout(8000) });
    const data = await res.json();
    const p = Array.isArray(data) ? data.find(x => x?.baseToken?.address === c.mint) : null;
    if (p?.baseToken?.symbol) { c.symbol = p.baseToken.symbol; c.name = p.baseToken.name || c.name; }
  } catch (_) { /* name stays short mint */ }
}

// v11.5: how much supply is still held by wallets that bought near the floor (they sell at 3-4x = the "12-15K dump")
function earlyBag(c) {
  let tok = 0;
  for (const [w, x] of c.wallets) if (w !== c.creator && x.entryMcap && x.entryMcap <= 1.3 * CFG.FLOOR_SOL && x.net > DUST) tok += x.net;
  return Math.round((tok / TOKEN_SUPPLY) * 1000) / 10;
}

// ---------------- Floor Hunter (v11.3) ----------------
// Young coin still near the curve's starting price: worst case is small, upside is open.
function floorChecks(c, at) {
  const m = computeMetrics(c, at);
  const ageSec = (at - c.createdAt) / 1000;
  const x = c.mcapSol / CFG.FLOOR_SOL;
  const last60 = c.trades.filter(t => at - t.t <= 60000);
  const buy1 = last60.reduce((a, t) => a + (t.side === "buy" ? t.sol : 0), 0);
  const sell1 = last60.reduce((a, t) => a + (t.side === "sell" ? t.sol : 0), 0);
  const buys = c.trades.filter(t => t.side === "buy" && t.wallet !== c.creator);
  const sizes = new Set(buys.map(t => t.sol.toFixed(2)));
  const variety = buys.length ? sizes.size / buys.length : 0;
  const h60 = c.holderHist.filter(h => at - h.t >= 50000 && at - h.t <= 70000).pop();
  const holdersNow = holderCount(c);
  const dev = c.dev || {};
  const nv = narrativeOf(c);
  const smartN = [...c.wallets.entries()].filter(([w, x2]) => x2.order !== null && w !== c.creator && x2.net > DUST && isSmart(w)).length;
  const ck = {
    devClean: !(dev.rugs >= 1) && (dev.launches24h || 0) < CFG.SERIAL_DEV_24H,
    devSmall: m.devPct <= CFG.FLOOR_MAX_DEV_PCT,
    devNotSelling: c.devSold === 0,
    earlyBotsLow: (m.bundlePct + m.sniperPct) <= CFG.FLOOR_MAX_EARLY_PCT,
    buyers: m.uniqueBuyers >= CFG.FLOOR_MIN_BUYERS,
    buyersNow: m.buyersLast1m >= CFG.FLOOR_MIN_BUYERS_1M,
    volumeGrowing: m.buyersLast1m >= m.buyersPrev1m,
    buyPressure: buy1 > sell1 * 1.2,
    noOneWhale: m.top1Pct <= CFG.FLOOR_MAX_TOP1_PCT && m.oneWalletShare <= 0.4,
    humanSizes: m.sameSecondSameSize <= 3 && variety >= 0.5,
    holding: m.holdRatio >= CFG.FLOOR_MIN_HOLD_RATIO,
    holdersUp: h60 ? holdersNow > h60.n : holdersNow >= 8,
  };
  const bonus = { trending: !!(nv && nv.count >= 4), social: (c.social?.count || 0) >= 1, smart: smartN >= 1, goodDev: (dev.graduated || 0) > 0 };
  return {
    m, ck, bonus, x: Math.round(x * 100) / 100, ageSec: Math.round(ageSec),
    // v11.4: last night's data — only these 4 checks went with more 2x; the others are recorded for study only
    pass: ck.devNotSelling && ck.buyersNow && ck.buyPressure && ck.holdersUp, bonusN: Object.values(bonus).filter(Boolean).length,
    vals: { bag: earlyBag(c), buy1: r2(buy1), sell1: r2(sell1), variety: r2(variety), holders: holdersNow, holders60: h60 ? h60.n : null, smartN,
      buyers: m.uniqueBuyers, b1: m.buyersLast1m, b0: m.buyersPrev1m, dev: m.devPct, early: r2(m.bundlePct + m.sniperPct), top1: m.top1Pct, hold: m.holdRatio },
  };
}

// v11.4: clean study data — features at fixed ages, outcome measured from THAT moment's price
function floorCheckpoints(c, at) {
  if (c.mcapSol === null || c.revival) return;
  const ageSec = (at - c.createdAt) / 1000;
  c.floorCps = c.floorCps || [];
  for (const sec of CFG.FLOOR_CP_SEC) {
    if (ageSec < sec || ageSec > sec + 20 || c.floorCps.some(p => p.sec === sec)) continue;
    if (c.buyers.size < 3 || c.mcapSol > 3 * CFG.FLOOR_SOL || c.mcapSol < 0.95 * CFG.FLOOR_SOL) { c.floorCps.push({ sec, skip: true }); continue; }
    const r = floorChecks(c, at);
    c.floorCps.push({ sec, at, mc: c.mcapSol, maxMc: c.mcapSol, minMc: c.mcapSol, ck: r.ck, bonus: r.bonus, vals: r.vals, x: r.x, pass: r.pass,
      dev: { g: c.dev?.graduated || 0, p: c.dev?.pumped || 0, f: c.dev?.faded || 0, n: c.dev?.closed || 0, d24: c.dev?.launches24h || 0 } });
  }
}

function floorTick(c, at) {
  if (c.floor || c.floorDone || c.mcapSol === null || c.revival) return;
  const ageSec = (at - c.createdAt) / 1000;
  if (ageSec > CFG.FLOOR_MAX_AGE_SEC) { c.floorDone = true; return; }
  if (ageSec < CFG.FLOOR_MIN_AGE_SEC) return;
  const x = c.mcapSol / CFG.FLOOR_SOL;
  if (x < 0.95) { c.floorDone = true; c.abnormal = true; return; }   // v11.6: below the pump.fun start price = different kind of coin, wrong mcap -> never signal
  if (x > CFG.FLOOR_MAX_X) {
    if (c.floorSnap && !c.floorSnap.leftAt) c.floorSnap.leftAt = at;   // ran away before passing
    return;
  }
  if (c.buyers.size < 5) return;
  if (!c.social && c.uri) void fetchSocial(c);
  const r = floorChecks(c, at);
  if (!c.floorSnap) {   // shadow record: what every early coin looked like (for tomorrow's analysis)
    c.floorSnap = { at, mc: c.mcapSol, maxMc: c.mcapSol, minMc: c.mcapSol, ck: r.ck, bonus: r.bonus, vals: r.vals, pass: false, firstPassAt: null };
  }
  if (!r.pass) { c.floorSnap.ck = r.ck; c.floorSnap.vals = r.vals; c.floorSnap.bonus = r.bonus; return; }
  c.floorSnap.pass = true; c.floorSnap.firstPassAt = at; c.floorSnap.ck = r.ck; c.floorSnap.vals = r.vals; c.floorSnap.bonus = r.bonus;
  c.floorSnap.mc = c.mcapSol; c.floorSnap.maxMc = c.mcapSol; c.floorSnap.minMc = c.mcapSol;
  fireFloor(c, r, at);
}

function floorReasons(r) {
  const g = [];
  if (r.ck.devClean) g.push("Dev முன்பு rug செய்யவில்லை");
  g.push(`${r.vals.buyers} வெவ்வேறு வாங்குபவர்கள், கடந்த 1 நிமிடத்தில் ${r.vals.b1} பேர் (முன் நிமிடம் ${r.vals.b0})`);
  g.push(`வாங்குதல் ${r.vals.buy1} SOL > விற்றல் ${r.vals.sell1} SOL`);
  g.push(`வாங்கியவர்களில் ${Math.round(r.vals.hold * 100)}% இன்னும் வைத்திருக்கிறார்கள்`);
  if (r.bonus.trending) g.push("🔥 ட்ரெண்டிங் பெயர்");
  if (r.bonus.social) g.push("Twitter / Telegram / Website உள்ளது");
  if (r.bonus.smart) g.push(`உண்மையான ஸ்மார்ட் வாலெட் ${r.vals.smartN} வாங்கியுள்ளது`);
  if (r.bonus.goodDev) g.unshift("✅ இந்த dev முன்பு graduate ஆன காயின் உருவாக்கியவர்");
  return g;
}

function fireFloor(c, r, at) {
  const usd = Math.round(c.mcapSol * solUsd);
  const floorUsd = Math.round(CFG.FLOOR_SOL * solUsd);
  const worst = Math.round((1 - CFG.FLOOR_SOL / c.mcapSol) * 100);
  c.floor = {
    at: iso(at), atMs: at, entryMcapSol: c.mcapSol, entryUsd: usd, floorUsd, worstPct: worst,
    reasons: floorReasons(r), bonusN: r.bonusN, bonus: r.bonus, vals: r.vals,
    maxX: 1, nowX: 1, minX: 1, tp1: false, closed: false, cash: 0, rem: 1, pnl: 0, reason: null, telegram: false,
  };
  floorList.unshift(c.mint);
  if (floorList.length > 300) floorList.pop();
  append(FLOOR_FILE, { type: "FLOOR_SIGNAL", timestamp: iso(at), mint: c.mint, symbol: c.symbol, entryUsd: usd, x: r.x, ageSec: r.ageSec, bonus: r.bonus, vals: r.vals });
  if (!BACKTEST()) console.log(`[FLOOR] ${c.symbol} $${usd} bonus ${r.bonusN} https://pump.fun/coin/${c.mint}`);
  if (r.bonus.goodDev && (DECISION() || tgAllowed("floor", CFG.FLOOR_TG_PER_HOUR))) {
    const ftxt = (
      `🎯 தரை வேட்டை — ${c.symbol}\n` +
      `மார்க்கெட் கேப் $${(usd / 1000).toFixed(1)}K (தரை $${(floorUsd / 1000).toFixed(1)}K · மோசமான நிலையிலும் சுமார் -${worst}%)\n` +
      c.floor.reasons.slice(0, 5).map(t => "✓ " + t).join("\n") + "\n" +
      `திட்டம்: $${(usd * 2 / 1000).toFixed(1)}K (2x)-இல் பாதி விற்கவும் · ${CFG.FLOOR_TIME_STOP_MIN} நிமிடத்தில் 1.5x வரவில்லை என்றால் வெளியேறவும்\n` +
      `(சோதனைக் காலம் - பணம் போட வேண்டாம்)\nhttps://pump.fun/coin/${c.mint}`);
    if (process.env.FLOOR_TG === "1") tgDecisionBuy(c.floor, ftxt, true, "floor", c.symbol);   // v11.8: floor hunting lost money in tests -> website only
  }
}

function floorStep(c, at) {
  const f = c.floor;
  if (!f || f.closed) return;
  const x = c.mcapSol / f.entryMcapSol;
  f.nowX = r2(x);
  if (x > f.maxX) f.maxX = r2(x);
  if (x < f.minX) f.minX = r2(x);
  const mins = (at - f.atMs) / 60000;
  const close = reason => {
    f.cash += f.rem * x; f.rem = 0; f.closed = true; f.reason = reason; f.closedAt = iso(at);
    f.pnl = r2(f.cash * (1 - CFG.FEE_ROUND_TRIP / 2) / (1 + CFG.FEE_ROUND_TRIP / 2) - 1);
    append(FLOOR_FILE, { type: "FLOOR_CLOSE", timestamp: iso(at), mint: c.mint, symbol: c.symbol, reason, exitX: r2(x), maxX: f.maxX, minX: f.minX, pnl: f.pnl, minutes: Math.round(mins) });
    if (f.telegram && reason !== "TP_DONE") tgFollow(f, `${f.pnl >= 0 ? "✅" : "🔴"} தரை வேட்டை முடிவு — ${c.symbol}\nவெளியேறு (${({ TRAIL: "உச்சத்திலிருந்து 35% விழுந்தது", TIME: "15 நிமிடத்தில் நகரவில்லை", DEV_SOLD: "Dev விற்றார்", GRADUATED: "Graduate ஆனது", END: "நேரம் முடிந்தது" })[reason] || reason})\nஇப்போது ${r2(x)}x · அதிகபட்சம் ${f.maxX}x · $3 போட்டிருந்தால்: $${(3 * (1 + f.pnl)).toFixed(2)}`);
  };
  if (!f.tp1 && x >= 2) {
    f.tp1 = true; f.cash += 0.5 * 2; f.rem = 0.5;
    append(FLOOR_FILE, { type: "FLOOR_TP", timestamp: iso(at), mint: c.mint, symbol: c.symbol, x: r2(x) });
    if (f.telegram) tgFollow(f, `💰 2x — ${c.symbol}\nபாதியை இப்போது விற்கவும் (போட்ட பணம் திரும்பும்). மீதி இலவசம்.\nhttps://pump.fun/coin/${c.mint}`);
  }
  if (c.foreverKind === "DEV_SOLD") return close("DEV_SOLD");
  if (c.graduated) return close("GRADUATED");
  if (f.tp1 && x < CFG.FLOOR_TRAIL * f.maxX) return close("TRAIL");
  if (!f.tp1 && mins >= CFG.FLOOR_TIME_STOP_MIN && f.maxX < 1.5) return close("TIME");
  if (!f.tp1 && f.maxX >= 1.5 && x < CFG.FLOOR_TRAIL * f.maxX && x < 1) return close("TRAIL");
  if (mins >= 120) return close("END");
  f.pnl = r2((f.cash + f.rem * x) * (1 - CFG.FEE_ROUND_TRIP / 2) / (1 + CFG.FEE_ROUND_TRIP / 2) - 1);
}

function floorView(c) {
  const f = c.floor;
  return { mint: c.mint, symbol: c.symbol, social: c.social && c.social.status === "OK" ? c.social : null, links: links(c.mint),
    floor: { ...f, vals: undefined }, holders: c.holderNow || 0, mcapUsd: c.mcapSol ? Math.round(c.mcapSol * solUsd) : null };
}

// ---------------- Metrics ----------------
function computeMetrics(c, at) {
  const ageSec = (at - c.createdAt) / 1000;
  const mcapUsd = c.mcapSol !== null ? c.mcapSol * solUsd : null;
  const peakUsd = c.peakMcapSol * solUsd;

  const w5 = c.trades.filter(x => at - x.t <= 300000);
  const w2 = w5.filter(x => at - x.t <= 120000);
  const sum = (arr, side) => arr.reduce((s, x) => s + (x.side === side ? x.sol : 0), 0);
  const buySol5 = sum(w5, "buy"), sellSol5 = sum(w5, "sell");
  const buySol2 = sum(w2, "buy"), sellSol2 = sum(w2, "sell");
  const buyerSet = arr => new Set(arr.filter(x => x.side === "buy").map(x => x.wallet));
  const buyers5 = buyerSet(w5).size;
  const traders5 = new Set(w5.map(x => x.wallet)).size;
  const buyersLast1m = buyerSet(w5.filter(x => at - x.t <= 60000)).size;
  const buyersPrev1m = buyerSet(w5.filter(x => at - x.t > 60000 && at - x.t <= 120000)).size;

  const perWalletBuy = new Map();
  for (const x of w5) if (x.side === "buy") perWalletBuy.set(x.wallet, (perWalletBuy.get(x.wallet) || 0) + x.sol);
  const maxOneWalletBuy = Math.max(0, ...perWalletBuy.values());
  const oneWalletShare = buySol5 > 0 ? maxOneWalletBuy / buySol5 : 0;

  const holders = [];
  let bundlePct = 0, bundleWallets = 0, smartBuyers = 0, smartHolding = 0;
  for (const [wallet, w] of c.wallets) {
    if (w.order !== null && wallet !== c.creator && isSmart(wallet)) {
      smartBuyers++;
      if (w.net > 0) smartHolding++;
    }
    if (w.net <= 0) continue;
    const pct = (w.net / TOKEN_SUPPLY) * 100;
    holders.push({ wallet, pct });
    if (wallet !== c.creator && c.launchTs !== null && w.firstTs <= c.launchTs + 1) {
      bundlePct += pct; bundleWallets++;
    }
  }
  holders.sort((a, b) => b.pct - a.pct);
  const devPct = c.creator ? ((c.wallets.get(c.creator)?.net || 0) / TOKEN_SUPPLY) * 100 : 0;
  const nonDev = holders.filter(h => h.wallet !== c.creator);
  const top1Pct = nonDev[0]?.pct || 0;
  const top10Pct = holders.slice(0, 10).reduce((s, h) => s + h.pct, 0);
  const devSoldRatio = c.devBought > 0 ? c.devSold / c.devBought : 0;

  const past = c.history.find(h => at - h.t <= 130000 && at - h.t >= 100000)
    || c.history.find(h => at - h.t <= 130000);
  const trend2m = past && past.mcapSol > 0 && c.mcapSol ? c.mcapSol / past.mcapSol : 1;
  const fromPeak = c.peakMcapSol > 0 && c.mcapSol ? c.mcapSol / c.peakMcapSol : 1;
  const curvePct = c.vSol !== null ? clamp01((c.vSol - 30) / 85) * 100 : null;

  // holders: now vs 2 minutes ago, and how many buyers are still holding
  const holdersNow = holderCount(c);
  const hPast = c.holderHist.find(h => at - h.t <= 130000 && at - h.t >= 100000) || c.holderHist[0];
  const holders2mAgo = hPast ? hPast.n : holdersNow;
  const holdRatio = c.buyers.size ? holdersNow / c.buyers.size : 1;

  // launch groups: bundle (same second as launch) and snipers (first 5 seconds)
  let bBought = 0, bSold = 0, sniperPct = 0, smartRecent = 0;
  for (const [wallet, w] of c.wallets) {
    if (wallet === c.creator || c.launchTs === null) continue;
    if (w.firstTs <= c.launchTs + 1) { bBought += w.boughtTok; bSold += w.soldTok; }
    else if (w.firstTs <= c.launchTs + 5 && w.net > 0) sniperPct += (w.net / TOKEN_SUPPLY) * 100;
    if (w.order !== null && isSmart(wallet) && at - w.firstAt <= 300000) smartRecent++;
  }
  const bundleSoldRatio = bBought > 0 ? bSold / bBought : 0;

  // short-term price shape from trades (last 3 minutes)
  const w3 = c.trades.filter(x => at - x.t <= 180000 && x.mc);
  let hiIdx = -1, hi = 0;
  w3.forEach((x, i) => { if (x.mc > hi) { hi = x.mc; hiIdx = i; } });
  const afterHi = hiIdx >= 0 ? w3.slice(hiIdx) : [];
  const lowAfterHi = afterHi.length ? Math.min(...afterHi.map(x => x.mc)) : null;
  // swing in last 5 min: biggest pullback (high H1 -> low L) and whether price broke back above H1
  let runMax = 0, swingHigh = null, swingLow = null, swingDip = 1;
  for (const x of c.trades) {
    if (at - x.t > 300000 || !x.mc) continue;
    if (x.mc > runMax) runMax = x.mc;
    const dd = x.mc / runMax;
    if (dd < swingDip) { swingDip = dd; swingHigh = runMax; swingLow = x.mc; }
  }
  const breakout = swingHigh !== null && c.mcapSol > swingHigh;

  // bot swarm: share of holders that arrived in the last 60s, and identical buys in the same second
  let burstHolders = 0;
  for (const [wallet, w] of c.wallets) if (w.net > DUST && wallet !== c.creator && at - w.firstAt <= 60000) burstHolders++;
  const burstShare = holdersNow ? burstHolders / holdersNow : 0;
  const bySecond = new Map();
  for (const x of c.trades) {
    if (x.side !== "buy" || at - x.t > 180000) continue;
    const k = x.ts + ":" + x.sol.toFixed(4);
    bySecond.set(k, (bySecond.get(k) || 0) + 1);
  }
  const sameSecondSameSize = Math.max(0, ...bySecond.values());
  // first 20 buyers: how much of what they bought have they sold?
  let e20b = 0, e20s = 0;
  for (const [wallet, w] of c.wallets) if (wallet !== c.creator && w.order !== null && w.order < 20) { e20b += w.boughtTok; e20s += w.soldTok; }
  const earlySoldRatio = e20b ? e20s / e20b : 0;
  // parabolic: from the lowest point of the last 3 min to now
  const w3all = c.trades.filter(x => at - x.t <= 180000 && x.mc);
  const low3 = w3all.length ? Math.min(...w3all.map(x => x.mc)) : null;
  const rise3 = low3 && c.mcapSol ? c.mcapSol / low3 : 1;
  const ago60 = c.trades.filter(x => x.mc && at - x.t >= 55000 && at - x.t <= 90000).pop();
  const spike1m = ago60 && c.mcapSol ? c.mcapSol / ago60.mc : 1;
  // ladder pump: price climbs step by step, but only a few wallets are paying for it
  const w10 = c.trades.filter(x => at - x.t <= 600000);
  const low10 = w10.filter(x => x.mc).reduce((mn, x) => Math.min(mn, x.mc), Infinity);
  const rise10 = Number.isFinite(low10) && c.mcapSol ? c.mcapSol / low10 : 1;
  const pw10 = new Map(); let buy10 = 0;
  for (const x of w10) if (x.side === "buy" && x.wallet !== c.creator) { pw10.set(x.wallet, (pw10.get(x.wallet) || 0) + x.sol); buy10 += x.sol; }
  const top3Share10 = buy10 > 0 ? [...pw10.values()].sort((a, b) => b - a).slice(0, 3).reduce((a, b) => a + b, 0) / buy10 : 0;
  const buyers10 = pw10.size;
  const last30 = c.trades.filter(x => at - x.t <= 30000);
  const buy30 = last30.reduce((s2, x) => s2 + (x.side === "buy" ? x.sol : 0), 0);
  const sell30 = last30.reduce((s2, x) => s2 + (x.side === "sell" ? x.sol : 0), 0);

  return {
    ageSec: Math.round(ageSec), mcapUsd: mcapUsd !== null ? Math.round(mcapUsd) : null,
    peakUsd: Math.round(peakUsd), uniqueBuyers: c.buyers.size, buyers5, traders5,
    buyersLast1m, buyersPrev1m,
    trades5: w5.length, buySol5: r2(buySol5), sellSol5: r2(sellSol5),
    buySol2: r2(buySol2), sellSol2: r2(sellSol2), oneWalletShare: r2(oneWalletShare),
    top1Pct: r2(top1Pct), top10Pct: r2(top10Pct), devPct: r2(devPct),
    devSoldPct: r2(devSoldRatio * 100), bundlePct: r2(bundlePct), bundleWallets,
    smartBuyers, smartHolding, smartRecent,
    holders: holdersNow, holders2mAgo, holderGrowth2m: holdersNow - holders2mAgo, holdRatio: r2(holdRatio),
    bundleSoldRatio: r2(bundleSoldRatio), sniperPct: r2(sniperPct),
    recentHighSol: hi || null, dipRatio: hi && lowAfterHi ? r2(lowAfterHi / hi) : null,
    bounce: lowAfterHi && c.mcapSol ? r2(c.mcapSol / lowAfterHi) : null, spike1m: r2(spike1m),
    buy30: r2(buy30), sell30: r2(sell30), rise10: r2(rise10), top3Share10: r2(top3Share10), buyers10,
    swingDip: r2(swingDip), breakout, swingBounce: swingLow && c.mcapSol ? r2(c.mcapSol / swingLow) : null,
    burstShare: r2(burstShare), sameSecondSameSize, earlySoldRatio: r2(earlySoldRatio), rise3: r2(rise3),
    hadDump: !!c.hadDump, parabolic: !!c.parabolicAt,
    trend2m: r2(trend2m), fromPeak: r2(fromPeak),
    curvePct: curvePct !== null ? Math.round(curvePct) : null,
    liquiditySol: c.vSol !== null ? r2(Math.max(0, c.vSol - 30)) : null,
  };
}

function score(m, c) {
  const s = {};
  s.buyers = clamp01(m.buyers5 / 30) * 14;
  s.holders = clamp01(m.holderGrowth2m / 12) * 10 + (m.holdRatio >= 0.65 ? 4 : m.holdRatio >= 0.55 ? 2 : 0);
  const pressure = m.buySol5 + m.sellSol5 > 0 ? m.buySol5 / (m.buySol5 + m.sellSol5) : 0.5;
  s.pressure = clamp01((pressure - 0.5) / 0.3) * 14;
  s.distribution = clamp01((45 - m.top10Pct) / 25) * 14;
  let trend = m.trend2m >= 1.3 ? 10 : m.trend2m >= 1 ? 5 + (m.trend2m - 1) / 0.3 * 5 : m.trend2m >= 0.85 ? 2 : 0;
  if (m.fromPeak < 0.7) trend = Math.max(0, trend - 6);
  s.trend = trend;
  const organic = m.trades5 > 0 ? m.traders5 / m.trades5 : 0;
  s.organic = clamp01((organic - 0.3) / 0.3) * 6;
  s.dev = (m.devPct <= 1 ? 6 : m.devPct <= 3 ? 4 : m.devPct <= 7 ? 1 : 0) + (c.dev?.graduated > 0 ? CFG.GOOD_DEV_BONUS : 0);
  const ii = c.intel?.status === "DONE" ? c.intel : null;
  s.smart = Math.min(14, (m.smartBuyers || 0) * 3 + (m.smartRecent || 0) * 2 + (ii ? ii.smartFamilies * 5 : 0));
  s.fresh = ii ? Math.min(5, heldFreshBig(c) * 2) : 0;
  s.accel = m.buyersLast1m >= 5 && m.buyersLast1m >= 1.5 * Math.max(1, m.buyersPrev1m) ? 4 : 0;
  const soc = c.social;
  s.social = soc?.status === "OK" ? (soc.count > 0 ? Math.min(5, soc.count * 2.5) : -4) : 0;
  const nv = narrativeOf(c);
  c.narrative = nv;
  s.narrative = nv && nv.count >= 5 ? (nv.leader ? 6 : 2) : 0;
  const total = Math.max(0, Math.min(100, Math.round(Object.values(s).reduce((a, b) => a + b, 0))));
  return { total, parts: Object.fromEntries(Object.entries(s).map(([k, v]) => [k, Math.round(v)])) };
}

// ---------------- Evaluation ----------------
function rejectForever(c, kind, text) {
  c.forever = text; c.foreverKind = kind; c.status = "REJECTED";
  counters.rejectedForever++;
  foreverReasons[kind] = (foreverReasons[kind] || 0) + 1;
}

function evaluate(c, at) {
  if (c.mcapSol === null) return;
  const m = computeMetrics(c, at);
  c.metrics = m;

  if (!c.forever && !c.signal) {
    const devSoldSupplyPct = (c.devSold / TOKEN_SUPPLY) * 100;
    if (c.creator && devSoldSupplyPct >= CFG.DEV_DUMP_SUPPLY_PCT) {
      rejectForever(c, "DEV_SOLD", `Dev மொத்த சப்ளையில் ${Math.round(devSoldSupplyPct)}% டம்ப் செய்தார்`);
    } else if (c.peakMcapSol * solUsd >= 8000 && m.fromPeak < CFG.DUMP_FROM_PEAK) {
      rejectForever(c, "DUMPED", `டம்ப்: உச்சம் $${m.peakUsd}-இலிருந்து ${Math.round((1 - m.fromPeak) * 100)}% விழுந்தது`);
    } else if (c.dev.rugs > 0 && !(c.dev.graduated > 0)) {
      rejectForever(c, "DEV_RUGGED_BEFORE", `இந்த dev முன்பு ${c.dev.rugs} காயின் ரக்/டம்ப் செய்தவர்`);
    } else if (c.dev.launches24h >= CFG.SERIAL_DEV_24H && !(c.dev.graduated > 0)) {
      rejectForever(c, "SERIAL_DEV", `இந்த dev 24 மணியில் ${c.dev.launches24h} காயின் வெளியிட்டார்`);
    }
    if (c.forever) return;
  }
  if (c.forever) return;

  // load socials once the coin starts moving
  if (!c.social && m.mcapUsd >= CFG.RADAR_MIN_USD) void fetchSocial(c);
  // wallet intelligence: first at ~$3K, refreshed every 60s inside the zone (cached, cheap)
  const nearZone = (m.mcapUsd >= 4000 && m.uniqueBuyers >= 10) || (c.revival && !c.intel);   // only coins that are really moving (saves Helius credits)
  if (nearZone && !c.intel?.running && (!c.intel || (m.mcapUsd >= CFG.ZONE_MIN_USD && nowMs() - (c.intel.requestedAt || 0) > 60000))) requestIntel(c);

  const fails = [], failCodes = [];
  const addFail = (code, text) => { fails.push(text); failCodes.push(code); };
  const R = !!c.revival;   // revival coin: trade-flow holder numbers are partial -> use real on-chain holders instead
  if (m.ageSec < CFG.MIN_AGE_SEC) addFail("TOO_NEW", "முதல் 5 நிமிடம் — bot-கள் நேரம், காத்திருக்கிறது");
  if (!R && m.uniqueBuyers < CFG.MIN_UNIQUE_BUYERS) addFail("FEW_BUYERS", `வாங்குபவர்கள் ${m.uniqueBuyers} மட்டும்`);
  if (m.buyers5 < CFG.MIN_BUYERS_5M) addFail("FEW_BUYERS_5M", `5 நிமிடத்தில் ${m.buyers5} வாங்குபவர்கள் மட்டும்`);
  if (!R && m.top1Pct > CFG.MAX_TOP1_PCT) addFail("WHALE_WALLET", `ஒரு வாலெட்டிடம் ${m.top1Pct}%`);
  if (!R && m.top10Pct > CFG.MAX_TOP10_PCT) addFail("TOP10_HEAVY", `டாப் 10 வாலெட்களிடம் ${m.top10Pct}%`);
  if (!R && m.devPct > CFG.MAX_DEV_PCT) addFail("DEV_HEAVY", `Dev-இடம் ${m.devPct}%`);
  if (!R && m.bundlePct > CFG.MAX_BUNDLE_PCT) addFail("BUNDLE", `Bundle வாலெட்களிடம் ${m.bundlePct}% (மிக அதிகம்)`);
  if (!R && m.bundlePct >= 8 && m.bundleSoldRatio > CFG.BUNDLE_SELL_REJECT) addFail("BUNDLE_SELLING", `Bundle வாலெட்கள் ஏற்கனவே ${Math.round(m.bundleSoldRatio * 100)}% விற்றுவிட்டார்கள்`);
  if (m.ageSec >= 120 && m.holders2mAgo >= 10 && m.holders < m.holders2mAgo * CFG.HOLDERS_FALL_PCT) addFail("HOLDERS_FALLING", `ஹோல்டர்கள் குறைகிறார்கள் (${m.holders2mAgo} → ${m.holders})`);
  if (m.uniqueBuyers >= 20 && m.holdRatio < CFG.MIN_HOLD_RATIO) addFail("LOW_HOLD_RATIO", `வாங்கியவர்களில் ${Math.round(m.holdRatio * 100)}% மட்டுமே இன்னும் வைத்திருக்கிறார்கள்`);
  if (m.oneWalletShare > CFG.MAX_ONE_WALLET_BUY_SHARE && m.buySol5 > 1) addFail("ONE_WALLET_PUMP", "ஒரே வாலெட் பெரும்பாலும் வாங்குகிறது");
  if (m.sellSol2 > 1 && m.sellSol2 > m.buySol2 * 1.5) addFail("SELLING_NOW", "இப்போது விற்பனை அதிகம் (டம்ப்)");
  // v10: fake-pump / bot-swarm protection
  if (!R && m.sniperPct > CFG.MAX_SNIPER_PCT) addFail("SNIPERS", `ஆரம்ப sniper-களிடம் ${m.sniperPct}% (முதல் பம்பில் விற்பார்கள்)`);
  if (m.holders >= 20 && m.burstShare > CFG.BURST_SHARE) addFail("BOT_SWARM", `ஹோல்டர்களில் ${Math.round(m.burstShare * 100)}% கடந்த 1 நிமிடத்தில் கூட்டமாக வந்தவர்கள்`);
  if (m.sameSecondSameSize >= CFG.SAME_SECOND_SAME_SIZE) addFail("SAME_SIZE_BUYS", `ஒரே வினாடியில் ${m.sameSecondSameSize} பேர் ஒரே தொகையில் வாங்கினார்கள் (bot)`);
  if (c.intel?.status === "DONE" && c.intel.freshShare != null && c.intel.checked >= 8 && c.intel.freshShare >= CFG.MAX_FRESH_SHARE) addFail("FRESH_WALLETS", `வாங்குபவர்களில் ${Math.round(c.intel.freshShare * 100)}% சில நிமிடம் முன் உருவான வாலெட்டுகள் (bot)`);
  if (!R && m.earlySoldRatio >= CFG.EARLY_SELL_RATIO && m.fromPeak >= 0.85 && m.ageSec < 20 * 60) addFail("EARLY_SELLING", `ஆரம்ப வாங்குபவர்கள் ${Math.round(m.earlySoldRatio * 100)}% விற்றுவிட்டார்கள் (உங்களுக்கு விற்கிறார்கள்)`);
  if (m.rise10 >= CFG.LADDER_RISE_10M && m.top3Share10 >= CFG.LADDER_TOP3_SHARE && m.buyers10 < CFG.LADDER_MAX_BUYERS)
    addFail("LADDER_PUMP", `படிப்படியாக ஏறுகிறது, ஆனால் ${Math.round(m.top3Share10 * 100)}% வாங்குதல் 3 வாலெட்டுகளிடமிருந்து மட்டும் (ஒரே மெழுகுவர்த்தியில் டம்ப் ஆபத்து)`);
  if (c.parabolicAt && !c.hadDump) addFail("PARABOLIC", "செங்குத்தாக 5 மடங்கு ஏறியது, முதல் டம்பைத் தாங்கும் வரை காத்திருக்கிறது");
  if (c.intel?.status === "DONE" && c.intel.realTop10Pct != null) {
    if (c.intel.realTop10Pct > CFG.MAX_REAL_TOP10_PCT) addFail("HIDDEN_SUPPLY", `உண்மையான டாப் 10 வாலெட்டுகளிடம் ${c.intel.realTop10Pct}% (மறைந்திருக்கும் சப்ளை)`);
    else if (c.intel.realTop1Pct > CFG.MAX_REAL_TOP1_PCT) addFail("HIDDEN_SUPPLY", `ஒரு வாலெட்டிடம் உண்மையில் ${c.intel.realTop1Pct}%`);
  }
  if (R && !(c.intel && (c.intel.status === "DONE" || c.intel.status === "ERROR" || c.intel.status === "BUDGET"))) addFail("REVIVAL_CHECKING", "பழைய காயின்: உண்மையான ஹோல்டர்களைச் சோதிக்கிறது");
  if (c.intel?.status === "DONE") {
    if (c.intel.devLinkedPct > CFG.MAX_DEV_LINKED_PCT || c.intel.devLinked > CFG.MAX_DEV_LINKED_WALLETS) addFail("DEV_LINKED", `Dev-இன் மறைமுக வாலெட்டுகளிடம் ${c.intel.devLinkedPct}%`);
    if (c.intel.familyWallets >= 3 && c.intel.familyPct > CFG.MAX_FAMILY_PCT) addFail("ONE_PERSON_MANY_WALLETS", `ஒருவரே ${c.intel.familyWallets} வாலெட்டுகளில் ${c.intel.familyPct}% வைத்திருக்கிறார்`);
  }

  const sc = score(m, c);
  c.score = sc.total;
  c.scoreParts = sc.parts;
  c.reasons = fails;
  c.failCodes = failCodes;

  const inZone = m.mcapUsd >= CFG.ZONE_MIN_USD && m.mcapUsd <= CFG.ZONE_MAX_USD;
  if (c.signal) { c.status = "SIGNAL"; return; }

  const intelWaiting = !BACKTEST() && c.intel?.status === "PENDING" && nowMs() - (c.intel.requestedAt || 0) < CFG.INTEL_WAIT_MS;
  const good = inZone && fails.length === 0 && sc.total >= CFG.SIGNAL_SCORE;
  if (!good) { c.readyAt = null; c.waitReason = null; }
  if (good && intelWaiting) {
    c.status = "READY";               // good so far - waiting a few seconds for the wallet check
    c.checking = true;
    c.waitReason = "வாலெட் சோதனை நடக்கிறது";
  } else if (good) {
    c.checking = false;
    c.readyAt = c.readyAt || nowMs();
    const entry = entryTiming(c, m);
    if (entry.ok) {
      c.entryType = entry.type;
      fireSignal(c, m, sc);
    } else {
      c.status = "READY";
      c.waitReason = entry.wait;
    }
  } else if (inZone && fails.length === 0 && sc.total >= CFG.WATCH_SCORE) {
    c.status = "WATCH";
  } else if (inZone) {
    c.status = "IN_ZONE_FAIL";
  } else {
    c.status = m.mcapUsd < CFG.ZONE_MIN_USD ? "BELOW_ZONE" : "ABOVE_ZONE";
  }
}

function heldFreshBig(c) {
  const list = c.intel?.freshBigWallets || [];
  const now = nowMs();
  return list.filter(w => { const x = c.wallets.get(w); return x && x.net > DUST && now - x.firstAt >= CFG.FRESH_BIG_HOLD_SEC * 1000; }).length;
}

function stars(total, m, c) {
  const ii = c.intel?.status === "DONE" ? c.intel : null;
  const smartAny = (m.smartBuyers || 0) + (ii?.smartFamilies || 0) > 0;
  const clean = !ii || (ii.devLinkedPct <= 2 && ii.familyPct <= 10);
  let s = 2;
  if (total >= 72) s++;
  if (smartAny || (c.narrative?.leader && c.narrative.count >= 5)) s++;
  if (m.holdRatio >= 0.65 && m.holderGrowth2m >= 5 && clean && m.bundlePct < 15) s++;
  return Math.min(5, s);
}

// Plain-language reasons for the simple screen / Telegram.
function explain(c, m) {
  const good = [], bad = [];
  const ii = c.intel?.status === "DONE" ? c.intel : null;
  const pressure = m.buySol5 + m.sellSol5 > 0 ? m.buySol5 / (m.buySol5 + m.sellSol5) : 0.5;
  const nv = c.narrative;
  if ((m.smartBuyers || 0) + (ii?.smartFamilies || 0) > 0) good.push("முன்பு வென்ற ட்ரேடர்கள் இதை வாங்கியுள்ளனர்");
  if (nv && nv.count >= 5 && nv.leader) good.push(`ட்ரெண்டிங் பெயர் "${nv.word}" (${nv.count} காயின்கள்), இதுதான் முன்னணி`);
  if (m.holderGrowth2m >= 5) good.push(`ஹோல்டர்கள் கூடுகிறார்கள் (${m.holders2mAgo} → ${m.holders})`);
  if (m.holdRatio >= 0.65 && m.uniqueBuyers >= 15) good.push(`வாங்கியவர்களில் ${Math.round(m.holdRatio * 100)}% இன்னும் வைத்திருக்கிறார்கள்`);
  if (c.entryType === "DIP") good.push("முதல் இறக்கத்துக்குப் பிறகு மீண்டும் ஏறுகிறது (நல்ல விலை)");
  if (c.entryType === "STEADY") good.push("சீராக ஏறுகிறது, செங்குத்தாக இல்லை");
  if (c.entryType === "MOMENTUM") good.push("ஹோல்டர்கள் வேகமாகக் கூடும் வலுவான ஏற்றம் (அபாயம் சற்று அதிகம், சிறிய தொகை)");
  if (c.entryType === "BREAKOUT") good.push("இறக்கத்துக்குப் பிறகு முந்தைய உச்சத்தை உடைத்தது (breakout)");
  if (ii && heldFreshBig(c) >= 2) good.push(`பெரிய பணத்துடன் வந்த ${heldFreshBig(c)} புதிய வாலெட்கள் 2+ நிமிடமாக வைத்திருக்கின்றன`);
  if (c.hadDump && !c.signal) good.push("முதல் டம்பைத் தாங்கி மீண்டும் ஏறியது");
  if (c.revival) good.push("பழைய காயின் மீண்டும் புதிய கூட்டத்தைப் பெறுகிறது");
  if (c.dev?.graduated > 0) good.push(`✅ இந்த dev முன்பு ${c.dev.graduated} காயினை graduate செய்தவர்`);
  if (ii && ii.realTop10Pct != null && ii.realTop10Pct <= 30) good.push(`உண்மையான டாப் 10 ஹோல்டர்கள் ${ii.realTop10Pct}% மட்டும் (பரவலாக உள்ளது)`);
  if (m.ageSec >= 300) good.push(`${Math.floor(m.ageSec / 60)} நிமிடமாக உயிருடன் உள்ளது`);
  if (m.buyers5 >= 15) good.push(`கடந்த 5 நிமிடத்தில் ${m.buyers5} பேர் வாங்கினார்கள்`);
  if (pressure >= 0.7) good.push("வாங்குவது விற்பதை விட மிக அதிகம்");
  if (m.top10Pct <= 30) good.push("காயின் பலரிடம் பரவியுள்ளது");
  if (m.devPct <= 1) good.push("Dev-இடம் காயின் இல்லை (ரக் செய்ய முடியாது)");
  if (ii && ii.devLinkedPct <= 2 && ii.familyPct <= 10) good.push("போலி / dev வாலெட்டுகள் கண்டுபிடிக்கப்படவில்லை");
  if ((c.social?.count || 0) > 0) good.push("X / Telegram பக்கம் உள்ளது");

  if (m.holderGrowth2m < 0) bad.push(`ஹோல்டர்கள் குறைகிறார்கள் (${m.holders2mAgo} → ${m.holders})`);
  if (m.uniqueBuyers >= 15 && m.holdRatio < 0.55) bad.push(`வாங்கியவர்களில் ${Math.round(m.holdRatio * 100)}% மட்டுமே வைத்திருக்கிறார்கள்`);
  if (m.bundlePct >= 15) bad.push(`Bundle ${m.bundlePct}%: அவர்கள் விற்க ஆரம்பித்தால் உடனே வெளியேறு`);
  if (m.sniperPct >= 10) bad.push(`ஆரம்ப sniper-களிடம் ${m.sniperPct}%`);
  if (m.top1Pct > 7) bad.push(`ஒரு வாலெட்டிடம் ${m.top1Pct}% உள்ளது`);
  if (m.top10Pct > 35) bad.push(`டாப் 10 வாலெட்களிடம் ${m.top10Pct}%`);
  if (ii && ii.familyPct > 10) bad.push(`ஒருவரே பல வாலெட்டுகளில் ${ii.familyPct}%`);
  if (ii && ii.devLinkedPct > 3) bad.push(`Dev-இன் மறைமுக வாலெட்டுகளிடம் ${ii.devLinkedPct}%`);
  if (pressure < 0.55) bad.push("விற்பனையும் அதிகமாக உள்ளது");
  if (c.social?.status === "OK" && !c.social.count) bad.push("X / Telegram பக்கம் இல்லை");
  if (c.intel?.status === "PENDING" && !BACKTEST()) bad.push("வாலெட் சோதனை இன்னும் முடியவில்லை");
  for (const r of c.reasons || []) if (bad.length < 4 && !bad.includes(r)) bad.push(r);
  return { good: good.slice(0, 4), bad: bad.slice(0, 4) };
}

// Pros don't buy a vertical green candle. Wait for the first dip that holds, or a calm climb.
function entryTiming(c, m) {
  const readySec = (nowMs() - (c.readyAt || nowMs())) / 1000;
  if (m.spike1m > CFG.SPIKE_1M) return { ok: false, wait: "செங்குத்தாக ஏறுகிறது, இறக்கத்துக்காகக் காத்திருக்கிறது" };
  const holdersOk = m.holders >= 0.9 * Math.max(c.peakHolders || 0, 1);
  if (m.dipRatio !== null && m.dipRatio >= CFG.DIP_MIN && m.dipRatio <= CFG.DIP_MAX &&
      m.bounce >= CFG.DIP_BOUNCE && holdersOk && m.buy30 > m.sell30) {
    return { ok: true, type: "DIP" };
  }
  // breakout: a real pullback (10-40%) happened in the last 5 min, then price broke above that high
  if (m.breakout && m.swingDip <= 0.9 && m.swingDip >= CFG.DIP_MIN && m.swingBounce >= 1.1 &&
      m.spike1m <= 1.25 && holdersOk && m.holderGrowth2m > 0 && m.buy30 > m.sell30) {
    return { ok: true, type: "BREAKOUT" };
  }
  // strong momentum: no dip comes, but the crowd keeps arriving and holding (not a vertical candle)
  if (c.hadDump && readySec >= CFG.MOMENTUM_CONFIRM_SEC && m.spike1m <= 1.3 && m.holderGrowth2m >= 10 &&
      m.holdRatio >= 0.7 && m.buy30 > m.sell30 && (c.score || 0) >= 70) {
    return { ok: true, type: "MOMENTUM" };
  }
  if (c.hadDump && readySec >= CFG.STEADY_READY_SEC && m.trend2m >= 1 && m.trend2m <= 1.3 && m.spike1m <= 1.15 &&
      m.holderGrowth2m > 0 && m.buy30 >= m.sell30) {
    return { ok: true, type: "STEADY" };
  }
  if (m.dipRatio !== null && m.dipRatio < CFG.DIP_MIN) return { ok: false, wait: "அதிகமாக இறங்கியது, நிலைபெறக் காத்திருக்கிறது" };
  if (!c.hadDump) return { ok: false, wait: "முதல் டம்பைத் தாங்குகிறதா என்று காத்திருக்கிறது" };
  return { ok: false, wait: "நல்ல விலைக்காகக் காத்திருக்கிறது (இறக்கம் அல்லது சீரான ஏற்றம்)" };
}

function exitPlan(entryUsd) {
  const e = entryUsd;
  return {
    entryUsd: e,
    tp1: { x: 2, mcapUsd: Math.round(e * 2), sellPct: 50 },
    tp2: { x: 5, mcapUsd: Math.round(e * 5), sellPct: 25 },
    trailingPct: 40,
    stop: { x: 0.6, mcapUsd: Math.round(e * 0.6) },
    timeStopMin: CFG.TIME_STOP_MIN,
  };
}

function groupNet(c, wallets) {
  let n = 0;
  for (const w of wallets) n += c.wallets.get(w)?.net || 0;
  return n;
}

function fireSignal(c, m, sc) {
  const at = nowMs();
  const st = stars(sc.total, m, c);
  const ii = c.intel?.status === "DONE" ? c.intel : {};
  const smartAny = (m.smartBuyers || 0) + (ii.smartFamilies || 0) > 0;
  const hot = st >= 4 && (smartAny || (c.narrative?.leader && c.narrative.count >= 5));
  c.status = "SIGNAL";

  // snapshot of who holds what at the moment of the signal (exit alerts compare against this)
  const bundleSet = [], top10 = [];
  for (const [wallet, w] of c.wallets) {
    if (wallet !== c.creator && c.launchTs !== null && w.firstTs <= c.launchTs + 1 && w.net > DUST) bundleSet.push(wallet);
  }
  [...c.wallets.entries()].filter(([w, x]) => w !== c.creator && x.net > DUST)
    .sort((a, b) => b[1].net - a[1].net).slice(0, 10).forEach(([w]) => top10.push(w));
  const smartHolders = [...c.wallets.entries()].filter(([w, x]) => x.net > DUST && isSmart(w)).map(([w]) => w);

  c.signal = {
    at: iso(at), atMs: at, mcapSol: c.mcapSol, mcapUsd: m.mcapUsd, solUsd: r2(solUsd),
    score: sc.total, scoreParts: sc.parts, tier: hot ? "HOT" : "SIGNAL", entryType: c.entryType,
    metrics: m, plan: exitPlan(m.mcapUsd), stars: st, why: null,
  };
  c.signal.why = explain(c, m);
  c.snap = {
    devNet: c.creator ? (c.wallets.get(c.creator)?.net || 0) : 0,
    bundle: bundleSet, bundleNet: groupNet(c, bundleSet),
    top10, top10Net: groupNet(c, top10),
    smart: smartHolders, holders: m.holders,
  };
  c.outcome = {
    maxX: 1, minX: 1, nowX: 1, checkpoints: {}, result: "RUNNING", graduated: false,
    warnings: [], source: "CURVE", hold: "HOLD", peakHolders: m.holders,
    paper: { rem: 1, cash: 0, tp1: false, tp2: false, closed: false, reason: null, pnl: 0 },
  };
  counters.signals++;
  if (hot) counters.hot++;
  append(SIGNALS_FILE, {
    type: "BUY_SIGNAL", timestamp: iso(at), mint: c.mint, symbol: c.symbol, name: c.name,
    creator: c.creator, social: c.social, dev: c.dev, narrative: c.narrative, ...c.signal,
    links: links(c.mint), analysisOnly: true, ordersPlaced: false,
  });
  recentSignals.unshift(c.mint);
  if (recentSignals.length > 200) recentSignals.pop();

  if (!BACKTEST()) console.log(
    `\n[BUY SIGNAL${hot ? " HOT" : ""}] ${c.symbol} | ${c.entryType} | mcap $${m.mcapUsd} | score ${sc.total} | ${st}* | ` +
    `holders ${m.holders} (${m.holderGrowth2m >= 0 ? "+" : ""}${m.holderGrowth2m}) | hold ${Math.round(m.holdRatio * 100)}% | https://pump.fun/coin/${c.mint}\n`
  );
  const w = c.signal.why, p = c.signal.plan, k = n => "$" + (n >= 1000 ? (n / 1000).toFixed(1) + "K" : n);
  c.signal.earlyBag = earlyBag(c);
  c.sigPath = { pts: [[0, 1, 1, 1]], done: false };
  const tgText = (
    `${hot ? "🔥" : "🟢"} வாங்கலாம் ${"★".repeat(st)}${"☆".repeat(5 - st)}${c.revival ? " 🔄 பழைய காயின்" : ""}\n` +
    `${c.symbol} — மார்க்கெட் கேப் ${k(m.mcapUsd)}\n` +
    `ஹோல்டர்கள் ${m.holders} (2 நிமிடத்தில் ${m.holderGrowth2m >= 0 ? "+" : ""}${m.holderGrowth2m})\n\n` +
    w.good.slice(0, 3).map(x => "✓ " + x).join("\n") +
    (w.bad.length ? "\n" + w.bad.slice(0, 2).map(x => "! " + x).join("\n") : "") +
    `\n\nதிட்டம்: ${k(p.tp1.mcapUsd)}-இல் பாதி விற்க · ${k(p.tp2.mcapUsd)}-இல் இன்னும் கால் · ${k(p.stop.mcapUsd)}-க்கு கீழே முழுதும் வெளியேறு\n` +
    `⏱ ${k(Math.round(m.mcapUsd * 1.5))}-க்கு மேல் போயிருந்தால் வாங்க வேண்டாம் (தாமதம்)\n` +
    `💰 மொத்தப் பணத்தில் 1-3% மட்டும் · வாங்கும் போதே ஆப்பில் TP / SL அமைக்கவும்\n` +
    `https://pump.fun/coin/${c.mint}\n(ஆய்வு மட்டும் - நிதி ஆலோசனை அல்ல)`
  );
  // v11.8: A grade = 4-5 stars, not an old "revival" coin, and holders did not jump in one burst (+100% in 2 min = bot crowd)
  const burst = m.holders2mAgo > 0 && m.holderGrowth2m > m.holders2mAgo;
  c.signal.grade = (st >= 4 && !c.revival && !burst) ? "A" : st >= 3 ? "B" : "C";
  tgDecisionBuy(c, tgText, c.signal.grade === "A", "main", c.symbol);
}

// v12: price path after a signal: one point per minute [minute, close, high, low] (x = price / entry price)
function pathNote(c, x) {
  const p = c.sigPath; if (!p || p.done || !Number.isFinite(x) || x <= 0) return;
  const m = Math.floor((nowMs() - c.signal.atMs) / 60000);
  if (m > 180) return pathFinish(c);
  let cur = p.pts[p.pts.length - 1];
  if (!cur || cur[0] !== m) { cur = [m, x, x, x]; p.pts.push(cur); }
  cur[1] = r3(x); if (x > cur[2]) cur[2] = r3(x); if (x < cur[3]) cur[3] = r3(x);
}
function pathFinish(c) {
  const p = c.sigPath; if (!p || p.done) return;
  p.done = true;
  append(PATH_FILE, { mint: c.mint, symbol: c.symbol, at: c.signal.at, entryUsd: c.signal.mcapUsd, stars: c.signal.stars, grade: c.signal.grade || null,
    entryType: c.signal.entryType || c.entryType || null, revival: !!c.revival, tg: !!c.telegram, earlyBag: c.signal.earlyBag ?? null, pts: p.pts });
}
const r3 = v => Math.round(v * 1000) / 1000;

function setX(c, x) {
  pathNote(c, x);
  const o = c.outcome;
  o.nowX = r2(x);
  if (x > o.maxX) o.maxX = r2(x);
  // no bot? -> tell the user the moment to take profit
  o.tp = o.tp || {};
  for (const [lvl, msg] of [[2, "பாதியை (50%) இப்போதே விற்கவும் — முதலீடு திரும்பி வந்துவிடும்"], [5, "மேலும் 25% விற்கவும் — மீதியை மட்டும் வைத்திருக்கவும்"]]) {
    if (x >= lvl && !o.tp[lvl]) {
      o.tp[lvl] = true;
      append(OUTCOMES_FILE, { type: "TAKE_PROFIT", level: lvl, timestamp: iso(nowMs()), mint: c.mint, symbol: c.symbol, x: r2(x) });
      tgFollow(c, `💰 ${lvl}x தொட்டது — ${c.symbol}\n${msg}\nhttps://pump.fun/coin/${c.mint}`);
    }
  }
  if (x < o.minX) o.minX = r2(x);
}

// Exit alerts: ONLY things that happen AFTER the signal. hard = 🔴 exit, soft = ⚠ be careful.
function updateOutcome(c) {
  const o = c.outcome;
  if (!o) return;
  if (o.source === "CURVE" && c.mcapSol) setX(c, c.mcapSol / c.signal.mcapSol);
  const x = o.nowX;
  const warn = (kind, level, text) => {
    if (o.warnings.some(w => w.kind === kind)) return;
    const alreadyExit = o.warnings.some(w => w.level === "hard");
    o.warnings.push({ kind, level, text, at: iso(nowMs()), x });
    if (alreadyExit) { append(OUTCOMES_FILE, { type: "WARNING", kind, level, text, timestamp: iso(nowMs()), mint: c.mint, symbol: c.symbol, x, maxX: o.maxX }); return; }  // one exit alert per coin is enough
    append(OUTCOMES_FILE, { type: "WARNING", kind, level, text, timestamp: iso(nowMs()), mint: c.mint, symbol: c.symbol, x, maxX: o.maxX });
    if (!BACKTEST()) console.log(`\n[${level === "hard" ? "EXIT" : "CAREFUL"}] ${c.symbol} | ${text} | now ${x}x (max ${o.maxX}x)\n`);
    if (level === "hard") {
      tgFollow(c, `🔴 முழுவதும் விற்கவும் — ${c.symbol}\n${text}\nஇப்போது ${x}x (அதிகபட்சம் ${o.maxX}x)\nhttps://pump.fun/coin/${c.mint}`);
    } else if (!BACKTEST()) {
      // soft alert: wait 60s; if an EXIT comes meanwhile, only the EXIT is sent
      const tmr = setTimeout(() => {
        if (o.warnings.some(w => w.level === "hard")) return;
        if (!DECISION()) void sendTelegram(`⚠ கவனமாக இரு — ${c.symbol}\n${text}\nஇப்போது ${o.nowX}x (அதிகபட்சம் ${o.maxX}x)\nhttps://pump.fun/coin/${c.mint}`);
      }, 60000);
      if (tmr.unref) tmr.unref();
    }
    if (level === "hard") paperClose(c, "EXIT_ALERT");
  };
  const sn = c.snap || {};
  const mins = (nowMs() - c.signal.atMs) / 60000;

  if (x <= 0.6) warn("STOP_LOSS", "hard", "Stop-loss நிலை (நுழைவில் 0.6 மடங்கு) தொட்டது");
  if (o.maxX >= 1.2 && x < o.maxX * CFG.EXIT_WARN_FROM_MAX) warn("FALLING", "hard", `உச்சத்திலிருந்து ${Math.round((1 - x / o.maxX) * 100)}% விழுந்தது`);

  if (o.source === "CURVE") {
    const holders = holderCount(c);
    if (holders > (o.peakHolders || 0)) o.peakHolders = holders;
    o.holders = holders;
    const priceWeak = x < 0.85 || x < 0.75 * o.maxX;    // v11: crowd-based exits need the price to confirm
    if (o.peakHolders >= 20 && holders <= o.peakHolders * CFG.HOLDERS_EXIT_DROP) {
      if (priceWeak) warn("HOLDERS_DROP", "hard", `ஹோல்டர்கள் வேகமாகக் குறைகிறார்கள் (${o.peakHolders} → ${holders}), விலையும் இறங்குகிறது`);
      else warn("HOLDERS_DROP_SOFT", "soft", `ஹோல்டர்கள் குறைகிறார்கள் (${o.peakHolders} → ${holders}), விலை இன்னும் நிற்கிறது`);
    }
    // price going up while no new holders arrive = few wallets pushing it -> good moment to take profit
    const hNow = c.holderHist[c.holderHist.length - 1], hOld = c.holderHist.find(h => nowMs() - h.t >= 100000 && nowMs() - h.t <= 140000);
    const pOld = c.history.find(h => nowMs() - h.t >= 100000 && nowMs() - h.t <= 140000);
    if (hNow && hOld && pOld && c.mcapSol / pOld.mcapSol >= 1.4 && hNow.n <= hOld.n && x >= 1.3) {
      warn("PUMP_NO_HOLDERS", "soft", "விலை ஏறுகிறது ஆனால் புதிய ஹோல்டர்கள் வரவில்லை — லாபம் எடுக்க நல்ல நேரம்");
    }
    if (sn.devNet >= 0.01 * TOKEN_SUPPLY && (c.wallets.get(c.creator)?.net || 0) <= sn.devNet * 0.5) warn("DEV_SOLD_AFTER", "hard", "சிக்னலுக்குப் பிறகு dev விற்றார்");
    if (sn.bundleNet >= 0.05 * TOKEN_SUPPLY && groupNet(c, sn.bundle) <= sn.bundleNet * CFG.GROUP_EXIT_LEFT) warn("BUNDLE_SELLING", "hard", "Bundle வாலெட்கள் விற்க ஆரம்பித்தார்கள்");
    if (sn.top10Net >= 0.10 * TOKEN_SUPPLY && groupNet(c, sn.top10) <= sn.top10Net * CFG.GROUP_EXIT_LEFT) {
      if (priceWeak) warn("TOP_SELLING", "hard", "பெரிய ஹோல்டர்கள் விற்கிறார்கள், விலையும் இறங்குகிறது");
      else warn("TOP_SELLING_SOFT", "soft", "பெரிய ஹோல்டர்கள் கொஞ்சம் விற்கிறார்கள் (விலை இன்னும் நிற்கிறது)");
    }
    if ((sn.smart || []).length >= 2 && sn.smart.filter(w => (c.wallets.get(w)?.net || 0) > DUST).length <= sn.smart.length / 2) warn("SMART_SELLING", "soft", "முன்பு வென்ற ட்ரேடர்கள் விற்கிறார்கள்");
  }
  const ii = c.intel?.status === "DONE" ? c.intel : null;
  if (ii && (ii.devLinkedPct > CFG.MAX_DEV_LINKED_PCT || ii.devLinked > CFG.MAX_DEV_LINKED_WALLETS)) warn("DEV_FARM", "hard", `Dev-இன் மறைமுக வாலெட்டுகள் கண்டுபிடிக்கப்பட்டன (${ii.devLinked} வாலெட், ${ii.devLinkedPct}%)`);
  if (ii && ii.familyWallets >= 3 && ii.familyPct > CFG.MAX_FAMILY_PCT) warn("ONE_PERSON", "hard", `ஒருவரே ${ii.familyWallets} வாலெட்டுகளில் ${ii.familyPct}% வைத்திருக்கிறார்`);
  if (mins >= CFG.TIME_STOP_MIN && o.maxX < 1.3) warn("TIME_STOP", "soft", `${CFG.TIME_STOP_MIN} நிமிடமாக நகரவில்லை, வெளியேறலாம்`);
  if (x < 0.8 && x > 0.6) warn("DIP", "soft", "நுழைவை விட 20% கீழே");

  o.hold = o.warnings.some(w => w.level === "hard") ? "EXIT" : o.warnings.some(w => w.level === "soft") ? "CAREFUL" : "HOLD";
  if (c.graduated && !o.graduated) {
    queueOutcome(c);
    o.graduated = true;
    o.source = "DEX";
    append(OUTCOMES_FILE, { type: "GRADUATED", timestamp: iso(nowMs()), mint: c.mint, symbol: c.symbol, x: o.nowX, maxX: o.maxX });
  }
  paperStep(c);
}

// Paper trade: what if you followed the plan exactly with the same amount every time?
function paperClose(c, reason) {
  const p = c.outcome?.paper;
  if (!p || p.closed) return;
  p.cash += p.rem * c.outcome.nowX; p.rem = 0; p.closed = true; p.reason = reason;
  paperValue(c);
}
function paperValue(c) {
  const p = c.outcome.paper, f = CFG.FEE_ROUND_TRIP / 2;
  const value = p.cash + p.rem * c.outcome.nowX;
  p.pnl = r2(value * (1 - f) / (1 + f) - 1);
}
function paperStep(c) {
  const o = c.outcome, p = o?.paper;
  if (!p || p.closed) return;
  const x = o.nowX;
  if (!p.tp1 && x >= 2) { p.cash += 0.5 * 2; p.rem = 0.5; p.tp1 = true; }
  if (p.tp1 && !p.tp2 && x >= 5) { p.cash += 0.25 * 5; p.rem = 0.25; p.tp2 = true; }
  if (!p.tp1 && x <= 0.6) return paperClose(c, "STOP");
  if (p.tp1 && x < 0.6 * o.maxX) return paperClose(c, "TRAIL");
  const mins = (nowMs() - c.signal.atMs) / 60000;
  if (!p.tp1 && mins >= CFG.TIME_STOP_MIN && o.maxX < 1.3) return paperClose(c, "TIME");
  if (mins >= 24 * 60) return paperClose(c, "END");
  paperValue(c);
}

// After graduation trades move off the bonding curve: follow price on DexScreener.
async function followGraduated(c) {
  try {
    const res = await fetch(DEX_API + encodeURIComponent(c.mint), { signal: AbortSignal.timeout(10000) });
    if (!res.ok) return;
    const data = await res.json();
    if (!Array.isArray(data)) return;
    const mcs = data
      .filter(p => p?.baseToken?.address === c.mint)
      .map(p => Number(p.marketCap ?? p.fdv))
      .filter(n => Number.isFinite(n) && n > 0);
    if (!mcs.length) return;
    const mc = Math.max(...mcs);
    setX(c, mc / c.signal.mcapUsd);
    c.dexMcapUsd = Math.round(mc);
    updateOutcome(c);
  } catch (_) { /* try again next round */ }
}

function checkOutcomes(at) {
  for (const mint of recentSignals) {
    const c = coins.get(mint);
    if (!c || !c.outcome) continue;
    const mins = (at - c.signal.atMs) / 60000;
    for (const cp of CHECKPOINTS_MIN) {
      if (mins >= cp && c.outcome.checkpoints[cp] === undefined) {
        c.outcome.checkpoints[cp] = c.outcome.nowX;
        c.outcome.result = resultOf(c.outcome);
        append(OUTCOMES_FILE, {
          type: "CHECKPOINT", timestamp: iso(at), mint, symbol: c.symbol, minutes: cp,
          entryMcapUsd: c.signal.mcapUsd, nowX: c.outcome.nowX, maxX: c.outcome.maxX,
          minX: c.outcome.minX, result: c.outcome.result, graduated: c.outcome.graduated,
        });
      }
    }
  }
}

function resultOf(o) {
  if (o.maxX >= 10) return "10X+";
  if (o.maxX >= 5) return "5X+";
  if (o.graduated) return "GRADUATED";
  if (o.maxX >= 2) return "2X+";
  if (o.nowX < 0.5) return "DUMPED";
  return "RUNNING";
}

// ---------------- Learning (when a coin's tracking ends) ----------------
function finalize(c) {
  if (c.sigPath && !c.sigPath.done) pathFinish(c);
  if (c.floor && !c.floor.closed && c.mcapSol) { floorStep(c, nowMs()); if (!c.floor.closed) { const f = c.floor; const x = c.mcapSol / f.entryMcapSol; f.cash += f.rem * x; f.rem = 0; f.closed = true; f.reason = "END"; f.pnl = r2(f.cash * (1 - CFG.FEE_ROUND_TRIP / 2) / (1 + CFG.FEE_ROUND_TRIP / 2) - 1); append(FLOOR_FILE, { type: "FLOOR_CLOSE", timestamp: iso(nowMs()), mint: c.mint, symbol: c.symbol, reason: "END", exitX: r2(x), maxX: f.maxX, minX: f.minX, pnl: f.pnl }); } }
  if (c.pro && !c.pro.closed && c.mcapSol) { proStep(c, nowMs()); if (!c.pro.closed) { const r = c.pro, x = c.mcapSol / r.entryMcapSol; r.cash += r.rem * x; r.rem = 0; r.closed = true; r.reason = "END"; r.pnl = r2(r.cash * (1 - CFG.FEE_ROUND_TRIP / 2) / (1 + CFG.FEE_ROUND_TRIP / 2) - 1); append(PRO_FILE, { type: "PRO_CLOSE", timestamp: iso(nowMs()), mint: c.mint, symbol: c.symbol, reason: "END", exitX: r2(x), maxX: r.maxX, pnl: r.pnl }); } }
  if (c.pro) proArchived = [{ mint: c.mint, symbol: c.symbol, pro: c.pro, archived: true }, ...proArchived].slice(0, 200);
  if (c.floor) floorArchived = [{ ...floorView(c), archived: true }, ...floorArchived.filter(x => x.mint !== c.mint)].slice(0, 300);
  if (c.floorSnap && !BACKTEST()) {
    const s0 = c.floorSnap;
    append(SHADOW_FILE, { mint: c.mint, symbol: c.symbol, creator: c.creator, at: iso(s0.at), entryUsd: Math.round(s0.mc * solUsd), pass: s0.pass, floorSignal: !!c.floor,
      maxX: r2(s0.maxMc / s0.mc), minX: r2(s0.minMc / s0.mc), hit2xFirst: !!s0.hit2At && (!s0.hit07At || s0.hit2At < s0.hit07At),
      hit2x: !!s0.hit2At, hit07: !!s0.hit07At, minsToMax: s0.maxAt ? Math.round((s0.maxAt - s0.at) / 60000) : 0,
      graduated: c.graduated, ck: s0.ck, bonus: s0.bonus, vals: s0.vals, pnl: c.floor ? c.floor.pnl : null });
  }
  if (c.floorCps && !BACKTEST()) for (const p of c.floorCps) {
    if (p.skip) continue;
    append(CP_FILE, { mint: c.mint, symbol: c.symbol, creator: c.creator, sec: p.sec, at: iso(p.at), usd: Math.round(p.mc * solUsd), x: p.x, pass: p.pass,
      maxX: r2(p.maxMc / p.mc), minX: r2(p.minMc / p.mc), hit2xFirst: !!p.hit2At && (!p.hit07At || p.hit2At < p.hit07At), hit2x: !!p.hit2At, hit07: !!p.hit07At,
      graduated: c.graduated, peakUsd: Math.round(c.peakMcapSol * solUsd), ck: p.ck, bonus: p.bonus, vals: p.vals, dev: p.dev });
  }
  let result = "FADED";
  if (c.foreverKind === "DEV_SOLD") result = "RUG_DEV";
  else if (c.foreverKind === "DUMPED") result = "DUMPED";
  else if (c.graduated) result = "GRADUATED";
  else if (c.startMcapSol && c.peakMcapSol >= 3 * c.startMcapSol) result = "PUMPED";

  if (c.levelSnaps) {
    append(ZONE_FILE, {
      mint: c.mint, symbol: c.symbol, created: iso(c.createdAt), solUsd: r2(solUsd),
      startUsd: c.startMcapSol ? Math.round(c.startMcapSol * solUsd) : null,
      peakUsd: Math.round(c.peakMcapSol * solUsd), lastUsd: c.mcapSol ? Math.round(c.mcapSol * solUsd) : null,
      graduated: c.graduated, result, forever: c.foreverKind,
      signal: c.signal ? { usd: c.signal.mcapUsd, score: c.signal.score, maxX: c.outcome?.maxX } : null,
      levels: c.levelSnaps,
    });
  }

  if (c.creator) {
    const list = devs.get(c.creator) || [];
    const rec = list.find(x => x.mint === c.mint);
    if (rec) rec.result = result;
  }

  // Early buyers (first 40, not dev): did the coin later go 3x from where they bought?
  if (c.peakMcapSol > 0) {
    for (const [wallet, w] of c.wallets) {
      if (w.order === null || w.order >= 40 || wallet === c.creator || !w.entryMcap || isBot(wallet)) continue;
      const win = c.peakMcapSol >= CFG.WIN_MULTIPLE * w.entryMcap;
      const s = smart.get(wallet);
      if (win) smart.set(wallet, { w: (s?.w || 0) + 1, l: s?.l || 0, last: nowMs() });
      else if (s) { s.l++; s.last = nowMs(); }
      // the "mother" wallet that funded this buyer learns too (burner wallets change, mothers don't)
      const f = intel.funderOf(wallet);
      if (f && !intel.isExchangeCached(f)) {
        const fs2 = families.get(f);
        if (win) families.set(f, { w: (fs2?.w || 0) + 1, l: fs2?.l || 0, last: nowMs() });
        else if (fs2) { fs2.l++; fs2.last = nowMs(); }
      }
    }
  }
}

// ---------------- Zone history: every coin's state at $5K / $10K / $25K ----------------
// Written when tracking ends, with how high it went. Used to compare winners vs losers.
function recordLevels(c, at) {
  const usd = c.mcapSol * solUsd;
  if (usd < LEVELS_USD[0]) return;
  c.levelSnaps = c.levelSnaps || {};
  for (const lv of LEVELS_USD) {
    if (usd >= lv && !c.levelSnaps[lv]) {
      const m = computeMetrics(c, at);
      c.levelSnaps[lv] = {
        min: Math.round(m.ageSec / 6) / 10, buyers: m.uniqueBuyers, b5: m.buyers5, buy5: m.buySol5, sell5: m.sellSol5,
        top1: m.top1Pct, top10: m.top10Pct, dev: m.devPct, devSold: r2((c.devSold / TOKEN_SUPPLY) * 100),
        bundle: m.bundlePct, smart: m.smartBuyers, score: c.score, status: c.status,
        fails: (c.failCodes || []).join("+"), social: c.social?.count ?? null,
      };
    }
  }
}

// Parabolic pumps and the "first dump": a real coin falls 20%+ once, holders stay, and it climbs again.
function trackDumps(c, at) {
  const ageSec = (at - c.createdAt) / 1000;
  const recent = c.trades.filter(x => at - x.t <= 180000 && x.mc);
  if (recent.length) {
    const low = Math.min(...recent.map(x => x.mc));
    if (!c.parabolicAt && c.mcapSol / low >= CFG.PARABOLIC_X) c.parabolicAt = at;
  }
  if (c.hadDump || ageSec < 60) return;
  const holders = c.holderNow || holderCount(c);
  if (!c.dumpTest && c.mcapSol <= c.peakMcapSol * CFG.DUMP_TEST) {
    c.dumpTest = { low: c.mcapSol, holdersAtPeak: Math.max(c.peakHolders || 0, holders) };
  }
  if (c.dumpTest) {
    if (c.mcapSol < c.dumpTest.low) c.dumpTest.low = c.mcapSol;
    if (c.mcapSol >= c.dumpTest.low * CFG.DUMP_RECOVER && holders >= c.dumpTest.holdersAtPeak * 0.8) c.hadDump = true;
    if (c.mcapSol < c.peakMcapSol * CFG.DUMP_FROM_PEAK) c.dumpTest = null;  // died instead (DUMPED rule handles it)
  }
}

// ---------------- timers ----------------
function tick() {
  const at = nowMs();
  for (const c of coins.values()) {
    if (c.mcapSol !== null) {
      const last = c.history[c.history.length - 1];
      if (!last || at - last.t >= 10000) {
        c.history.push({ t: at, mcapSol: c.mcapSol });
        if (c.history.length > 200) c.history.shift();
      }
    }
    if (c.mcapSol !== null) recordLevels(c, at);
    if (c.lastTradeAt && at - c.lastTradeAt < 10 * 60000) {
      const lastH = c.holderHist[c.holderHist.length - 1];
      if (!lastH || at - lastH.t >= 10000) {
        const n = holderCount(c);
        c.holderNow = n;
        if (n > c.peakHolders) c.peakHolders = n;
        c.holderHist.push({ t: at, n });
        if (c.holderHist.length > 40) c.holderHist.shift();
      }
    }
    if (c.signal && c.outcome && !c.outcome.paper.closed && !c.archived) { updateOutcome(c); }
    if (c.sigPath && !c.sigPath.done) {
      if ((at - c.signal.atMs) / 60000 > 180) pathFinish(c);
      else if (c.outcome) pathNote(c, c.outcome.nowX);
    }
    if ((at - c.createdAt) / 1000 <= 270) floorCheckpoints(c, at);
    if (!c.floor) floorTick(c, at); else if (!c.floor.closed && c.mcapSol) floorStep(c, at);
    if (!c.signal && c.mcapSol !== null && c.lastTradeAt && at - c.lastTradeAt < 10 * 60000) trackDumps(c, at);
    const ageMin = (at - c.createdAt) / 60000;
    if (!c.signal && ageMin <= CFG.MAX_AGE_MIN && c.lastTradeAt && at - c.lastTradeAt < 10 * 60000) {
      evaluate(c, at);
    } else if (c.signal && c.mcapSol !== null && !c.outcome?.graduated) {
      c.metrics = computeMetrics(c, at);   // keep card numbers live after the signal
      if (!c.intel?.running && at - (c.intel?.requestedAt || 0) > 120000 && at - c.signal.atMs < 60 * 60000) requestIntel(c);
    }
  }
  checkOutcomes(at);
  smartAlertCheck(at);
}

// ---------------- True outcomes (after graduation the curve stream can't see the price) ----------------
function gradTrack(c) {
  if (BACKTEST() || gradList.some(g => g.mint === c.mint)) return;
  const at = nowMs();
  let m = null; try { m = computeMetrics(c, at); } catch (_) {}
  gradList.push({ mint: c.mint, symbol: c.symbol, creator: c.creator, gradAt: at, createdAt: c.createdAt,
    secToGrad: Math.round((at - c.createdAt) / 1000), instant: (at - c.createdAt) / 1000 <= CFG.GRAD_INSTANT_SEC,
    buyers: c.buyers.size, top1: m ? m.top1Pct : null, devG: c.dev?.graduated || 0, signal: !!c.signal, snaps: [], rocket: null });
  if (gradList.length > 400) gradList.splice(0, gradList.length - 400);
}
async function gradTick() {
  if (BACKTEST()) return;
  const at = nowMs();
  const due = gradList.filter(g => {
    const mins = (at - g.gradAt) / 60000;
    if (mins <= CFG.GRAD_WATCH_MIN) return true;
    if (g.rocket && !g.rocket.closed && mins <= CFG.ROCKET_FOLLOW_H * 60) return Math.floor(mins) % 5 === 0;
    return false;
  });
  for (let i = 0; i < due.length; i += 30) {
    const batch = due.slice(i, i + 30);
    let data = null;
    try {
      const res = await fetch("https://api.dexscreener.com/tokens/v1/solana/" + batch.map(g => g.mint).join(","), { signal: AbortSignal.timeout(15000) });
      data = await res.json();
    } catch (_) { continue; }
    const best = {};
    if (Array.isArray(data)) for (const p of data) {
      const a = p?.baseToken?.address; if (!a) continue;
      if (!best[a] || (p.liquidity?.usd || 0) > (best[a].liquidity?.usd || 0)) best[a] = p;
    }
    for (const g of batch) {
      const p = best[g.mint]; if (!p) continue;
      const mins = Math.round((at - g.gradAt) / 60000);
      const snap = { m: mins, mc: Math.round(Number(p.marketCap ?? p.fdv) || 0), liq: Math.round(p.liquidity?.usd || 0),
        b5: p.txns?.m5?.buys || 0, s5: p.txns?.m5?.sells || 0, v5: Math.round(p.volume?.m5 || 0), mk5: p.txns?.m5?.makers || null, boost: p.boosts?.active || 0,
        soc: (p.info?.socials || []).length + (p.info?.websites || []).length };
      if (!snap.mc) continue;
      g.snaps.push(snap);
      if (g.symbol === "UNKNOWN" && p.baseToken?.symbol) g.symbol = p.baseToken.symbol;
      rocketCheck(g, snap, at);
      if (g.rocket && !g.rocket.closed) rocketStep(g, snap, at);
    }
  }
  // finished: write study line
  const keep = [];
  for (const g of gradList) {
    const mins = (at - g.gradAt) / 60000;
    const following = g.rocket && !g.rocket.closed && mins <= CFG.ROCKET_FOLLOW_H * 60;
    if (mins > CFG.GRAD_WATCH_MIN + 1 && !following) {
      if (g.rocket && !g.rocket.closed) rocketClose(g, g.snaps[g.snaps.length - 1]?.mc || g.rocket.entryMc, "END", at);
      append(GRAD_FILE, { mint: g.mint, symbol: g.symbol, creator: g.creator, grad: iso(g.gradAt), secToGrad: g.secToGrad, instant: g.instant, buyers: g.buyers, top1: g.top1, devG: g.devG, signal: g.signal, snaps: g.snaps, rocket: g.rocket });
      if (g.rocket) rocketArchived = [{ ...rocketView(g), archived: true }, ...rocketArchived].slice(0, 300);
    } else keep.push(g);
  }
  gradList = keep;
}
function rocketCheck(g, snap, at) {
  if (g.rocket || g.rocketSkip) return;
  if (snap.m < CFG.ROCKET_FROM_MIN) return;
  if (snap.m > CFG.ROCKET_TO_MIN) { g.rocketSkip = true; return; }
  const ok = g.instant && snap.mc >= CFG.ROCKET_MIN_USD && snap.mc <= CFG.ROCKET_MAX_USD && snap.liq >= CFG.ROCKET_MIN_LIQ && snap.b5 > snap.s5;
  if (!ok) return;
  g.rocket = { at: iso(at), atMs: at, entryMc: snap.mc, liq: snap.liq, b5: snap.b5, s5: snap.s5, maxX: 1, nowX: 1, minX: 1, tp1: false, tp2: false, cash: 0, rem: 1, pnl: 0, closed: false, reason: null };
  append(ROCKET_FILE, { type: "ROCKET_SIGNAL", timestamp: iso(at), mint: g.mint, symbol: g.symbol, mcapUsd: snap.mc, minsAfterGrad: snap.m, liq: snap.liq, b5: snap.b5, s5: snap.s5, secToGrad: g.secToGrad });
  if (!BACKTEST()) console.log(`[ROCKET] ${g.symbol} $${snap.mc} ${snap.m} min after graduation`);
  const k = n => "$" + (n >= 1e6 ? (n / 1e6).toFixed(2) + "M" : (n / 1000).toFixed(1) + "K");
  // v11.10: first live test 3/3 crashed (bot volume, one-candle dumps) -> paper only until the study proves it. ROCKET_TG=1 to turn back on.
  if (process.env.ROCKET_TG === "1") tgDecisionBuy(g.rocket,
    `🚀 Graduation வாய்ப்பு — ${g.symbol}\n` +
    `மார்க்கெட் கேப் ${k(snap.mc)} · Graduate ஆகி ${snap.m} நிமிடம் · Liquidity ${k(snap.liq)}\n` +
    `கடந்த 5 நிமிடம்: ${snap.b5} வாங்கல் / ${snap.s5} விற்றல்\n` +
    `ஆபத்து அதிகம் (பாதியாக விழலாம்) — சிறிய தொகை மட்டும்\n` +
    `திட்டம் (GMGN TP/SL): ${k(snap.mc * 2)}-இல் பாதி · ${k(snap.mc * 4)}-இல் மீதியில் பாதி · ${k(snap.mc / 2)}-க்கு கீழே எல்லாம்\n` +
    `https://gmgn.ai/sol/token/${g.mint}`, true, "rocket", g.symbol);
}
function rocketClose(g, mc, reason, at) {
  const r = g.rocket; if (!r || r.closed) return;
  const x = mc / r.entryMc;
  r.cash += r.rem * x; r.rem = 0; r.closed = true; r.reason = reason; r.nowX = r2(x);
  r.pnl = r2(r.cash * (1 - CFG.FEE_ROUND_TRIP / 2) / (1 + CFG.FEE_ROUND_TRIP / 2) - 1);
  append(ROCKET_FILE, { type: "ROCKET_CLOSE", timestamp: iso(at), mint: g.mint, symbol: g.symbol, reason, exitX: r2(x), maxX: r.maxX, minX: r.minX, pnl: r.pnl });
  if (reason === "STOP") tgFollow(r, `🔴 முழுவதும் விற்கவும் — ${g.symbol}\nபாதியாக விழுந்தது (${r2(x)}x)`);
}
function rocketStep(g, snap, at) {
  const r = g.rocket, x = snap.mc / r.entryMc;
  r.nowX = r2(x); if (x > r.maxX) r.maxX = r2(x); if (x < r.minX) r.minX = r2(x);
  if (!r.tp1 && x >= 2) { r.tp1 = true; r.cash += 0.5 * 2; r.rem = 0.5; tgFollow(r, `💰 2x — ${g.symbol}\nபாதியை விற்கவும் (GMGN TP தானாக விற்றிருக்கும்)`); }
  if (r.tp1 && !r.tp2 && x >= 4) { r.tp2 = true; r.cash += 0.25 * 4; r.rem = 0.25; tgFollow(r, `💰 4x — ${g.symbol}\nமீதியில் பாதியை விற்கவும். கடைசி 25% இலவச டிக்கெட்.`); }
  if (x <= 0.5) return rocketClose(g, snap.mc, "STOP", at);
  r.pnl = r2((r.cash + r.rem * x) * (1 - CFG.FEE_ROUND_TRIP / 2) / (1 + CFG.FEE_ROUND_TRIP / 2) - 1);
}
function rocketView(g) {
  return { mint: g.mint, symbol: g.symbol, gradAt: iso(g.gradAt), secToGrad: g.secToGrad, links: { gmgn: `https://gmgn.ai/sol/token/${g.mint}`, dexscreener: `https://dexscreener.com/solana/${g.mint}` },
    rocket: g.rocket, last: g.snaps[g.snaps.length - 1] || null };
}
// nightly summary (one message)
function summaryTick() {
  if (BACKTEST() || !DECISION()) return;
  const d = new Date(nowMs());
  if (d.getHours() !== CFG.TG_SUMMARY_HOUR || tgState.summaryDay === localDay()) return;
  tgState.summaryDay = localDay(); saveTg();
  const dayStart = new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
  const main = [...recentSignals.map(m => coins.get(m)).filter(Boolean).map(c => view(c, false)), ...archived].filter(x => x.signal && new Date(x.signal.at).getTime() >= dayStart);
  const mp = main.map(x => x.outcome?.paper?.pnl || 0);
  const rk = [...gradList.filter(g => g.rocket).map(rocketView), ...rocketArchived].filter(x => x.rocket.atMs >= dayStart);
  const sentTxt = (tgState.sent || []).map(x => x.symbol).join(", ") || "இல்லை";
  void sendTelegram(`📊 இன்றைய சுருக்கம்\n` +
    `அனுப்பிய "🟢 வாங்கு": ${tgState.day === localDay() ? tgState.buys : 0} (${sentTxt})\n` +
    `பெரிய சிக்னல்கள் (paper): ${main.length} · லாபம் ${mp.filter(p => p > 0).length} · $3 கணக்கில் $${(3 * main.length).toFixed(0)} → $${(3 * main.length + 3 * mp.reduce((a, b) => a + b, 0)).toFixed(2)}\n` +
    `🚀 Graduation (paper): ${rk.length} · 2x தொட்டவை ${rk.filter(x => x.rocket.maxX >= 2).length}\n` +
    `(சோதனைக் காலம் - இது பயிற்சி மட்டும்)`);
}

// v12: GeckoTerminal "trending pools" (free API). Every token that enters the list is followed for 6 hours.
async function trendTick() {
  if (BACKTEST()) return;
  const at = nowMs();
  try {
    const res = await fetch("https://api.geckoterminal.com/api/v2/networks/solana/trending_pools?page=1", { headers: { accept: "application/json" }, signal: AbortSignal.timeout(15000) });
    const j = await res.json();
    const pools = Array.isArray(j?.data) ? j.data : [];
    pools.forEach((p, i) => {
      const a = p.attributes || {}, base = p.relationships?.base_token?.data?.id || "";
      const mint = base.startsWith("solana_") ? base.slice(7) : null;
      if (!mint || trendSeen.has(mint)) return;
      trendSeen.add(mint);
      const n = v => (v == null ? null : Math.round(Number(v)));
      const tx = a.transactions || {}, pc = a.price_change_percentage || {};
      trendList.push({ mint, name: (a.name || "").slice(0, 40), pool: a.address, firstAt: at, rank: i + 1,
        entry: { mc: n(a.market_cap_usd) || n(a.fdv_usd), fdv: n(a.fdv_usd), liq: n(a.reserve_in_usd), vol1h: n(a.volume_usd?.h1), vol24: n(a.volume_usd?.h24),
          ch5m: Number(pc.m5) || 0, ch1h: Number(pc.h1) || 0, ch6h: Number(pc.h6) || 0, ch24h: Number(pc.h24) || 0,
          b1h: tx.h1?.buys ?? null, s1h: tx.h1?.sells ?? null, buyers1h: tx.h1?.buyers ?? null, sellers1h: tx.h1?.sellers ?? null,
          created: a.pool_created_at || null }, path: [] });
    });
  } catch (_) { /* try next round */ }
  // follow every trending token (DexScreener batch, 30 per call)
  const live = trendList.filter(t => at - t.firstAt <= 6 * 3600 * 1000);
  for (let i = 0; i < live.length; i += 30) {
    const batch = live.slice(i, i + 30);
    try {
      const res = await fetch("https://api.dexscreener.com/tokens/v1/solana/" + batch.map(t => t.mint).join(","), { signal: AbortSignal.timeout(15000) });
      const data = await res.json();
      const best = {};
      if (Array.isArray(data)) for (const p of data) { const a = p?.baseToken?.address; if (a && (!best[a] || (p.liquidity?.usd || 0) > (best[a].liquidity?.usd || 0))) best[a] = p; }
      for (const t of batch) {
        const p = best[t.mint]; if (!p) continue;
        const mc = Math.round(Number(p.marketCap ?? p.fdv) || 0); if (!mc) continue;
        t.path.push([Math.round((at - t.firstAt) / 60000), mc, p.txns?.m5?.buys || 0, p.txns?.m5?.sells || 0, Math.round(p.liquidity?.usd || 0)]);
        if (!t.entry.mc) t.entry.mc = mc;
      }
    } catch (_) {}
  }
  const keep = [];
  for (const t of trendList) {
    if (at - t.firstAt > 6 * 3600 * 1000 + 60000) append(TREND_FILE, t); else keep.push(t);
  }
  trendList = keep;
  if (trendSeen.size > 20000) { trendSeen.clear(); for (const t of trendList) trendSeen.add(t.mint); }
}

function queueOutcome(c) {
  gradTrack(c);
  if (BACKTEST() || outcomeQueue.some(q => q.mint === c.mint)) return;
  outcomeQueue.push({ mint: c.mint, symbol: c.symbol, gradAt: nowMs(), signal: c.signal ? c.signal.mcapUsd : null, done: {} });
  if (outcomeQueue.length > 3000) outcomeQueue.splice(0, outcomeQueue.length - 3000);
}
async function outcomeTick() {
  const at = nowMs();
  const due = [];
  for (const q of outcomeQueue) {
    for (const h of CFG.OUTCOME_CHECK_H) if (q.done[h] === undefined && at - q.gradAt >= h * 3600 * 1000) { due.push([q, h]); break; }
  }
  for (let i = 0; i < due.length && i < 90; i += 30) {
    const batch = due.slice(i, i + 30);
    try {
      const res = await fetch("https://api.dexscreener.com/tokens/v1/solana/" + batch.map(([q]) => q.mint).join(","), { signal: AbortSignal.timeout(15000) });
      const data = await res.json();
      const best = {};
      if (Array.isArray(data)) for (const p of data) {
        const a = p?.baseToken?.address, mc = Number(p.marketCap ?? p.fdv);
        if (a && Number.isFinite(mc)) best[a] = Math.max(best[a] || 0, mc);
      }
      for (const [q, h] of batch) {
        q.done[h] = best[q.mint] ? Math.round(best[q.mint]) : 0;
        append(TRUE_FILE, { mint: q.mint, symbol: q.symbol, hoursAfterGraduation: h, mcapUsd: q.done[h], signalUsd: q.signal, timestamp: iso(at) });
      }
    } catch (_) { /* try next minute */ }
  }
  outcomeQueue = outcomeQueue.filter(q => !CFG.OUTCOME_CHECK_H.every(h => q.done[h] !== undefined));
  try { if (!BACKTEST()) fs.writeFileSync(OQ_FILE, JSON.stringify(outcomeQueue)); } catch (_) {}
}

function followTick() {
  const at = nowMs();
  for (const mint of recentSignals) {
    const c = coins.get(mint);
    if (c?.outcome?.source === "DEX" && at - c.signal.atMs < 200 * 60000) void followGraduated(c);
  }
}

function cleanup() {
  const at = nowMs();
  for (const [mint, p] of pending) if (at - p.at > 30000) pending.delete(mint);
  for (const [mint, r] of revival) if (at - (r.lastAt || r.first) > 10 * 60000) revival.delete(mint);
  for (const [mint, sc] of smartCoins) if (at - sc.first > 2 * 3600 * 1000) smartCoins.delete(mint);
  for (const [mint, m] of proBuys) { for (const [w, wt] of m) if (at - wt > 120000) m.delete(w); if (!m.size) proBuys.delete(mint); }
  for (const [mint, c] of coins) {
    const ageMin = (at - c.createdAt) / 60000;
    const done = c.signal
      ? ageMin > 24 * 60
      : ageMin > CFG.MAX_AGE_MIN + 30 || (c.lastTradeAt === null && ageMin > 10) ||
        (c.lastTradeAt && at - c.lastTradeAt > 20 * 60000);
    if (done) {
      if (c.signal) archived = [{ ...view(c, false), archived: true }, ...archived.filter(x => x.mint !== c.mint)];
      finalize(c);
      coins.delete(mint);
      const i = recentSignals.indexOf(mint);
      if (i >= 0) recentSignals.splice(i, 1);
    } else if (c.trades.length) {
      const cut = at - 11 * 60000;   // keep 11 min of trades (ladder check needs 10)
      let i = 0;
      while (i < c.trades.length && c.trades[i].t < cut) i++;
      if (i) c.trades.splice(0, i);
    }
  }
  while (tradeTimes.length && at - tradeTimes[0] > 60000) tradeTimes.shift();
  for (const [w, m] of botSeen) {
    for (const [mint, t] of m) if (at - t > 3600 * 1000) m.delete(mint);
    if (!m.size) botSeen.delete(w);
  }
  for (const [w, list] of narr) {
    const kept = list.filter(x => at - x.t <= 2 * 3600 * 1000);
    if (kept.length) narr.set(w, kept); else narr.delete(w);
  }
}

// ---------------- Output for website ----------------
function links(mint) {
  return {
    gmgn: `https://gmgn.ai/sol/token/${mint}`,
    pumpfun: `https://pump.fun/coin/${mint}`,
    dexscreener: `https://dexscreener.com/solana/${mint}`,
    solscan: `https://solscan.io/token/${mint}`,
  };
}

function view(c, withHistory = true) {
  return {
    mint: c.mint, symbol: c.symbol, name: c.name, status: c.status, score: c.score,
    scoreParts: c.scoreParts || null, reasons: c.reasons, rejected: c.forever,
    metrics: c.metrics, dev: c.dev, creator: c.creator,
    social: c.social && c.social.status === "OK" ? c.social : null,
    signal: c.signal ? { ...c.signal, metrics: undefined } : null,
    outcome: c.outcome, dexMcapUsd: c.dexMcapUsd || null, links: links(c.mint),
    checking: !!c.checking, waitReason: c.waitReason || null, narrative: c.narrative || null, revival: !!c.revival,
    entryType: c.entryType || null, tg: !!c.telegram, grade: c.signal?.grade || null,
    why: c.signal ? explain(c, c.metrics || c.signal.metrics || {}) : (c.metrics ? explain(c, c.metrics) : null),
    whyAtSignal: c.signal?.why || null,
    stars: c.signal?.stars || (c.metrics ? stars(c.score, c.metrics, c) : null),
    intel: c.intel ? { status: c.intel.status, devLinked: c.intel.devLinked, devLinkedPct: c.intel.devLinkedPct, familyPct: c.intel.familyPct, freshBig: c.intel.freshBig, smartFamilies: c.intel.smartFamilies } : null,
    history: withHistory ? c.history.slice(-60).map(h => Math.round(h.mcapSol * solUsd)) : undefined,
  };
}

function getState() {
  const at = nowMs();
  const statusCount = {};
  const watch = [], zone = [], radar = [], sonar = [];
  const failCount = {};
  for (const c of coins.values()) {
    statusCount[c.status] = (statusCount[c.status] || 0) + 1;
    const m = c.metrics;
    if (m && c.lastTradeAt && at - c.lastTradeAt < 5 * 60000 && m.mcapUsd >= 2000) {
      sonar.push({ mint: c.mint, symbol: c.symbol, mcapUsd: m.mcapUsd, buyers5: m.buyers5, status: c.status, score: c.score });
    }
    if (c.signal) continue;
    if (c.status === "WATCH" || c.status === "READY") watch.push(view(c));
    else if (c.status === "IN_ZONE_FAIL") {
      zone.push(view(c, false));
      for (const k of c.failCodes || []) failCount[k] = (failCount[k] || 0) + 1;
    } else if (c.status === "BELOW_ZONE" && m && m.mcapUsd >= CFG.RADAR_MIN_USD && m.buyers5 >= 5) {
      radar.push(view(c));
    }
  }
  watch.sort((a, b) => (b.status === "READY") - (a.status === "READY") || b.score - a.score);
  zone.sort((a, b) => b.score - a.score);
  radar.sort((a, b) => (b.metrics.buyers5 - a.metrics.buyers5) || (b.score - a.score));
  sonar.sort((a, b) => b.score - a.score);

  const live = recentSignals.map(m => coins.get(m)).filter(Boolean).map(c => view(c));
  const liveSet = new Set(live.map(x => x.mint));
  const signals = [...live, ...archived.filter(x => !liveSet.has(x.mint))]
    .sort((a, b) => new Date(b.signal.at) - new Date(a.signal.at));
  const done = signals.filter(s => s.outcome && Object.keys(s.outcome.checkpoints).length);
  const avgMax = signals.length ? r2(signals.reduce((s, x) => s + (x.outcome?.maxX || 1), 0) / signals.length) : null;
  const summary = {
    total: signals.length,
    hot: signals.filter(s => s.signal?.tier === "HOT").length,
    hit2x: signals.filter(s => s.outcome?.maxX >= 2).length,
    hit5x: signals.filter(s => s.outcome?.maxX >= 5).length,
    hit10x: signals.filter(s => s.outcome?.maxX >= 10).length,
    dumped: done.filter(s => s.outcome?.result === "DUMPED").length,
    avgMaxX: avgMax,
  };
  const smartCount = [...smart.keys()].filter(isSmart).length;
  // paper trade summary (same amount on every signal, plan followed exactly)
  const papers = signals.map(x => x.outcome?.paper).filter(Boolean);
  summary.paperTrades = papers.length;
  summary.paperPnl = r2(papers.reduce((a, p) => a + (p.pnl || 0), 0));
  summary.paperWins = papers.filter(p => p.pnl > 0).length;
  // trending names right now
  const trending = [];
  for (const [w, list] of narr) {
    const n = list.filter(x => at - x.t <= 3600 * 1000).length;
    if (n >= 4) {
      let lead = null;
      for (const x of list) { const o = coins.get(x.mint); if (o && (!lead || (o.holderNow || 0) > (lead.holderNow || 0))) lead = o; }
      trending.push({ word: w, count: n, leader: lead ? { symbol: lead.symbol, mint: lead.mint, mcapUsd: lead.metrics?.mcapUsd || null, holders: lead.holderNow || 0 } : null });
    }
  }
  trending.sort((a, b) => b.count - a.count);
  const seenLead = new Set();
  const trendingUnique = trending.filter(t => { const k = t.leader?.mint || t.word; if (seenLead.has(k)) return false; seenLead.add(k); return true; });
  return {
    timestamp: iso(at), solUsd: r2(solUsd), solUsdSource, config: CFG,
    feed: {
      tradesPerMin: tradeTimes.filter(t => at - t <= 60000).length,
      lastTradeAgoSec: lastTradeAt ? Math.round((at - lastTradeAt) / 1000) : null,
    },
    counters: { ...counters, tracking: coins.size, smartWallets: smartCount, devsKnown: devs.size,
      smartFamilies: [...families.keys()].filter(isSmartFamily).length },
    intel: intel.stats(), trending: trendingUnique.slice(0, 6), kolCount: kols.size,
    myWalletCount: myWallets.size,
    smartFeed: smartFeed.slice(0, 60).map(e => ({ ...e, symbol: e.symbol || coins.get(e.mint)?.symbol || null })),
    smartCoins: [...smartCoins.entries()].filter(([, v]) => v.passed).sort((a, b) => b[1].wallets.size - a[1].wallets.size).slice(0, 15)
      .map(([mint, v]) => ({ mint, symbol: v.symbol || coins.get(mint)?.symbol || null, wallets: v.wallets.size, mcapUsd: v.mcapUsd,
        names: [...v.wallets.keys()].map(w => myWallets.get(w) || (w.slice(0, 4) + "…")) })),
    outcomesPending: outcomeQueue.length,
    floor: (() => {
      const live = floorList.map(m => coins.get(m)).filter(c => c && c.floor).map(floorView);
      const liveSet = new Set(live.map(x => x.mint));
      const all = [...live, ...floorArchived.filter(x => !liveSet.has(x.mint))].sort((a, b) => b.floor.atMs - a.floor.atMs);
      const closed = all.filter(x => x.floor.closed);
      return {
        list: all.slice(0, 80),
        summary: { total: all.length, closed: closed.length, hit2x: all.filter(x => x.floor.maxX >= 2).length,
          wins: closed.filter(x => x.floor.pnl > 0).length, pnlSum: r2(closed.reduce((a, x) => a + x.floor.pnl, 0)) },
      };
    })(),
    bots: [...botSeen.values()].filter(m => m.size >= CFG.BOT_MINTS_PER_HOUR).length,
    rocket: (() => {
      const live = gradList.filter(g => g.rocket).map(rocketView);
      const all = [...live, ...rocketArchived].sort((a, b) => b.rocket.atMs - a.rocket.atMs);
      const closed = all.filter(x => x.rocket.closed);
      return { list: all.slice(0, 50), watching: gradList.length,
        summary: { total: all.length, closed: closed.length, hit2x: all.filter(x => x.rocket.maxX >= 2).length, wins: closed.filter(x => x.rocket.pnl > 0).length, pnlSum: r2(closed.reduce((a, x) => a + x.rocket.pnl, 0)) } };
    })(),
    pro: (() => {
      const live = [...coins.values()].filter(c => c.pro).map(c => ({ mint: c.mint, symbol: c.symbol, pro: c.pro }));
      const all = [...live, ...proArchived.filter(x => !live.some(l => l.mint === x.mint))].sort((a, b) => b.pro.atMs - a.pro.atMs);
      const closed = all.filter(x => x.pro.closed);
      return { wallets: proSet.size, tracked: Object.keys(ledger.w).length, openPositions: positions.size,
        hours: ledger.started ? Math.round((nowMs() - ledger.started) / 3600000) : 0, list: all.slice(0, 40),
        summary: { total: all.length, closed: closed.length, hit2x: all.filter(x => x.pro.maxX >= 2).length, wins: closed.filter(x => x.pro.pnl > 0).length, pnlSum: r2(closed.reduce((a, x) => a + x.pro.pnl, 0)) } };
    })(),
    tg: { mode: DECISION() ? "decision" : "all", buysToday: tgState.day === localDay() ? tgState.buys : 0, max: CFG.TG_DAILY_BUYS },
    statusCount, summary, foreverReasons, failCount,
    signals, watch: watch.slice(0, 30), radar: radar.slice(0, 20),
    inZoneRejected: zone.slice(0, 20), sonar: sonar.slice(0, 160),
    analysisOnly: true, ordersPlaced: false,
  };
}

function loadArchive() {
  try {
    const list = JSON.parse(fs.readFileSync(ARCHIVE_FILE, "utf8"));
    const cutoff = nowMs() - 48 * 3600 * 1000;
    archived = list.filter(x => x?.signal?.at && new Date(x.signal.at).getTime() > cutoff).map(x => ({ ...x, archived: true }));
    if (archived.length) console.log(`[SIGNAL ENGINE] restored ${archived.length} earlier signals`);
  } catch (_) { archived = []; }
  try {
    const cutoff = nowMs() - 48 * 3600 * 1000;
    floorArchived = JSON.parse(fs.readFileSync(path.join(__dirname, "floor_archive.json"), "utf8")).filter(x => x?.floor?.atMs > cutoff).map(x => ({ ...x, archived: true }));
  } catch (_) { floorArchived = []; }
}
function saveArchive() {
  if (BACKTEST()) return;
  try {
    const live = recentSignals.map(m => coins.get(m)).filter(Boolean).map(c => ({ ...view(c, false), archived: true }));
    const liveSet = new Set(live.map(x => x.mint));
    const cutoff = nowMs() - 48 * 3600 * 1000;
    const all = [...live, ...archived.filter(x => !liveSet.has(x.mint))].filter(x => new Date(x.signal.at).getTime() > cutoff).slice(0, 300);
    fs.writeFileSync(ARCHIVE_FILE, JSON.stringify(all));
    const fl = [...floorList.map(m => coins.get(m)).filter(c => c && c.floor).map(c => ({ ...floorView(c), archived: true })), ...floorArchived];
    const seenF = new Set();
    fs.writeFileSync(path.join(__dirname, "floor_archive.json"), JSON.stringify(fl.filter(x => !seenF.has(x.mint) && seenF.add(x.mint) && x.floor.atMs > cutoff).slice(0, 300)));
  } catch (e) { console.error("[SIGNAL ARCHIVE]", e.message); }
}

function start() {
  loadMemory();
  loadArchive();
  timers.push(setInterval(saveArchive, 60000));
  void refreshSolPrice();
  timers.push(setInterval(refreshSolPrice, 60000));
  timers.push(setInterval(tick, 5000));
  timers.push(setInterval(cleanup, 30000));
  timers.push(setInterval(followTick, 30000));
  timers.push(setInterval(() => { void outcomeTick(); }, 60000));
  timers.push(setInterval(saveMemory, 120000));
  timers.push(setInterval(() => { void gradTick(); }, 60000));
  timers.push(setInterval(summaryTick, 60000));
  timers.push(setInterval(ledgerMaintain, 5 * 60000));
  timers.push(setInterval(() => { void trendTick(); }, 5 * 60000));
  setTimeout(() => { void trendTick(); }, 20000);
  loadTg();
  loadLedger();
  setTimeout(ledgerMaintain, 15000);
  timers.forEach(t => t.unref && t.unref());
  console.log(`[SIGNAL ENGINE] zone $${CFG.ZONE_MIN_USD}-$${CFG.ZONE_MAX_USD}, signal score >= ${CFG.SIGNAL_SCORE}. Analysis only.`);
}

function stop() {
  timers.forEach(clearInterval);
  timers = [];
  saveArchive();
  // save what we learned from coins still in memory (Ctrl+C)
  for (const c of coins.values()) { try { finalize(c); } catch (_) {} }
  coins.clear();
  saveMemory();
}

module.exports = {
  start, stop, onCreate, onTrade, getState,
  _test: { coins, tick, cleanup, finalize, evaluate, computeMetrics, smart, devs,
    setSolUsd: p => { solUsd = p; }, getSmart: () => smart, CFG, loadMemory, saveMemory, saveArchive, loadArchive,
    revival, outcomeQueue: () => outcomeQueue, outcomeTick, smartFeed, myWallets: () => myWallets,
    isBot, botSeen, floorChecks, holderStairs, smartCoins, gradList: () => gradList, gradTick, trendTick, trendList: () => trendList, pathFinish, ledger: () => ledger, ledgerMaintain, proSet: () => proSet, positions, earlyBag, tgState: () => tgState, summaryTick },
};
